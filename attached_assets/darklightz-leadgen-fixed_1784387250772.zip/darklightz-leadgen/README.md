# Darklightz Studio — Lead Generation Suite

> **A free, locally-run Windows desktop application built exclusively for Darklightz Studio.**  
> Find local businesses that don't have a website — your next potential clients.

---

```
  DARKLIGHTZ STUDIO
  Professional Lead Generation Suite
  Crafting Inevitable Futures.
```

---

## Quick Start

### Option A — Run from Source (no build needed)

1. **Install Python 3.11** → https://www.python.org/downloads/  
   Tick **"Add Python to PATH"** during setup.

2. **Open a terminal in this folder** and run:

```batch
pip install -r requirements.txt
playwright install chromium
python main.py
```

### Option B — Build a Windows `.exe`

```batch
build.bat
```

Double-click `build.bat` — it installs everything and produces:

```
dist\DarklightzLeadGenerator\DarklightzLeadGenerator.exe
dist\DarklightzLeadGenerator\ms-playwright\   ← Chromium bundled here
```

**The `.exe` carries Chromium with it** — ZIP the entire
`dist\DarklightzLeadGenerator\` folder to share. The target PC needs nothing
installed.

See [INSTALL.md](INSTALL.md) for the full step-by-step guide.

---

## Features

### 🔍 Lead Search
- Enter a **keyword** (e.g. `Restaurant`, `Salon`, `Gym`)
- Enter a **city** (e.g. `Lahore`, `Karachi`, `Dubai`)
- Set how many leads you want (up to 2000)
- Click **Start Search** — the app uses Chromium to browse Google Maps

### 🎯 Automatic Filtering
Only businesses matching at least one of these are collected:

| Condition | Priority |
|-----------|----------|
| No website at all | 🔴 Highest |
| Only an Instagram profile | 🟠 High |
| Only a Facebook page | 🟠 High |
| Only a WhatsApp link | 🟠 High |
| Only a social media presence | 🟡 Medium |

Businesses with a **real website** are automatically **skipped**.

### 📋 Lead Table
Each lead shows:
- Business Name, Phone, WhatsApp, Instagram, Facebook
- Address, Rating, Review Count
- Lead Type (No Website / Social Only / Facebook Only …)
- Status (editable via right-click)
- Notes (double-click to open full editor)

### ✏️ Status Tracking
Right-click any row to set status:
- **New** → **Contacted** → **Follow-up** → **Interested** → **Closed** / **Not Interested**

### 📝 Notes
Double-click any lead's Notes cell to open a full text editor.  
Notes are saved automatically to the local database.

### 📤 Export
| Format | Details |
|--------|---------|
| Excel  | Styled `.xlsx` with dark header row |
| CSV    | UTF-8, opens in Excel or Google Sheets |
| PDF    | Landscape A4 with Darklightz Studio branding |

Filter by status before exporting (e.g. export only "Interested" leads).

### 🗄️ Local Database
- SQLite — stored at `~/.darklightz/leads.db`
- Survives restarts, reinstalls, and updates
- Duplicates are automatically prevented

---

## Technology Stack (100% Free & Open Source)

| Library | Purpose | Licence |
|---------|---------|---------|
| Python 3 | Core runtime | PSF |
| PyQt6 | Desktop UI | GPL v3 |
| Playwright (Chromium) | Google Maps scraping | Apache 2 |
| SQLite | Local database | Public domain |
| openpyxl | Excel export | MIT |
| reportlab | PDF export | BSD |

**No paid APIs. No subscriptions. No credit card. Everything runs locally.**

---

## How the Playwright / Chromium Fix Works

When packaged with PyInstaller, `build.bat`:
1. Builds the `.exe` and bundles the Playwright driver (node runtime)
2. Copies `%LOCALAPPDATA%\ms-playwright\` into `dist\DarklightzLeadGenerator\ms-playwright\`

At startup, `backend/scraper.py` detects it is running as a frozen executable
and sets `PLAYWRIGHT_BROWSERS_PATH` to the `ms-playwright` folder next to the
`.exe` — so Playwright always finds Chromium regardless of what is installed on
the target machine.

---

## Project Structure

```
darklightz-leadgen/
├── main.py                  # Application entry point
├── requirements.txt         # Python dependencies
├── build.bat                # Windows build script → .exe (with bundled Chromium)
│
├── assets/
│   ├── logo.png             # Darklightz Studio logo
│   └── icon.ico             # Application icon (all sizes)
│
├── backend/
│   └── scraper.py           # Google Maps Playwright scraper
│                            # (includes frozen-exe Chromium path fix)
│
├── database/
│   ├── models.py            # SQLite schema creation
│   └── operations.py        # CRUD operations
│
├── frontend/
│   ├── splash_screen.py     # Startup splash screen
│   ├── main_window.py       # App window + sidebar + footer
│   ├── dashboard_widget.py  # Stats dashboard
│   ├── search_widget.py     # Search form + progress log
│   ├── leads_widget.py      # Lead table + filters
│   ├── export_widget.py     # Export buttons
│   ├── settings_widget.py   # App settings
│   ├── about_widget.py      # About page with branding
│   └── styles.py            # Dark QSS stylesheet
│
├── exports/
│   ├── excel_exporter.py    # .xlsx export
│   ├── csv_exporter.py      # .csv export
│   └── pdf_exporter.py      # .pdf export
│
└── utilities/
    ├── helpers.py           # URL classification, text utils
    └── logger.py            # Rotating file logger
```

---

## Legal Notice

This application scrapes publicly visible data from Google Maps.  
Google's Terms of Service prohibit automated scraping.  
**Use at your own risk and responsibility.**  
Darklightz Studio bears no liability for misuse.

---

## Copyright

© Darklightz Studio. All rights reserved.  
Developed exclusively for Darklightz Studio internal use.
