"""
General-purpose helper utilities for Darklightz Lead Generator.
"""

from __future__ import annotations
import re
from urllib.parse import urlparse


# ---------------------------------------------------------------------------
# Social-media / known domain lists
# ---------------------------------------------------------------------------

SOCIAL_DOMAINS = {
    "facebook.com", "www.facebook.com", "fb.com", "m.facebook.com",
    "instagram.com", "www.instagram.com",
    "wa.me", "api.whatsapp.com", "whatsapp.com",
    "twitter.com", "x.com", "t.co",
    "tiktok.com", "www.tiktok.com",
    "youtube.com", "youtu.be", "www.youtube.com",
    "linkedin.com", "www.linkedin.com",
    "snapchat.com",
    "pinterest.com",
    "linktr.ee",
    "linktree.com",
}

FACEBOOK_PATTERNS = re.compile(r"facebook\.com|fb\.com|m\.facebook\.com", re.I)
INSTAGRAM_PATTERNS = re.compile(r"instagram\.com", re.I)
WHATSAPP_PATTERNS = re.compile(r"wa\.me|whatsapp\.com|api\.whatsapp\.com", re.I)


def classify_lead(website: str) -> str:
    """
    Classify a business based on its website URL.

    Returns one of:
        'No Website'          — no URL at all
        'No Online Presence'  — effectively no digital footprint
        'Facebook Only'       — only Facebook page
        'Instagram Only'      — only Instagram profile
        'WhatsApp Only'       — only WhatsApp link
        'Social Only'         — social platform but not specifically one above
        'Has Website'         — real website → should be skipped

    Only leads that are NOT 'Has Website' are collected.
    """
    if not website or not website.strip():
        return "No Website"

    url = website.strip().lower()

    # Normalise — add scheme so urlparse works
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        # Strip leading www.
        hostname = re.sub(r"^www\.", "", hostname)
    except Exception:
        return "No Website"

    if FACEBOOK_PATTERNS.search(hostname):
        return "Facebook Only"
    if INSTAGRAM_PATTERNS.search(hostname):
        return "Instagram Only"
    if WHATSAPP_PATTERNS.search(hostname):
        return "WhatsApp Only"
    if hostname in SOCIAL_DOMAINS or any(hostname.endswith("." + d) for d in SOCIAL_DOMAINS):
        return "Social Only"

    return "Has Website"


def should_include_lead(website: str) -> bool:
    """Return True if the business should be included as a lead."""
    return classify_lead(website) != "Has Website"


def extract_instagram_from_text(text: str) -> str:
    """Pull an Instagram handle/URL from arbitrary text."""
    patterns = [
        r"instagram\.com/([A-Za-z0-9_.]+)",
        r"@([A-Za-z0-9_.]{3,30})",
    ]
    for p in patterns:
        m = re.search(p, text, re.I)
        if m:
            return m.group(0)
    return ""


def extract_facebook_from_text(text: str) -> str:
    m = re.search(r"(facebook\.com/[^\s\"'>]+)", text, re.I)
    return m.group(0) if m else ""


def extract_whatsapp_from_text(text: str) -> str:
    """Extract a WhatsApp number from text (wa.me links or plain numbers)."""
    m = re.search(r"wa\.me/(\d+)", text, re.I)
    if m:
        return "+" + m.group(1)
    # Pakistani mobile numbers starting with 03xx
    m = re.search(r"\b(0?3\d{2}[-\s]?\d{7})\b", text)
    if m:
        return m.group(1)
    return ""


def clean_phone(phone: str) -> str:
    """Normalise a phone number string."""
    if not phone:
        return ""
    # Remove common junk characters but keep +, digits, spaces, dashes
    cleaned = re.sub(r"[^\d+\s\-()]", "", phone).strip()
    return cleaned


def truncate(text: str, max_len: int = 60) -> str:
    """Truncate a string for display."""
    return text if len(text) <= max_len else text[: max_len - 3] + "..."
