"""
Export leads to an Excel (.xlsx) file using openpyxl.
No paid libraries required — openpyxl is MIT-licensed.
"""

from __future__ import annotations
import os
from datetime import datetime
from typing import Sequence

import openpyxl
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side
)
from openpyxl.utils import get_column_letter


COLUMNS = [
    ("Business Name", "name", 30),
    ("Phone",         "phone", 16),
    ("WhatsApp",      "whatsapp", 30),
    ("Instagram",     "instagram", 30),
    ("Facebook",      "facebook", 30),
    ("Address",       "address", 35),
    ("Rating",        "rating", 8),
    ("Reviews",       "reviews", 10),
    ("Lead Type",     "lead_type", 16),
    ("Status",        "status", 14),
    ("City",          "city", 14),
    ("Notes",         "notes", 45),
    ("Created",       "created_at", 20),
]

# Dark header colours matching the app theme
HEADER_BG   = "1E1E2E"    # dark background
HEADER_FG   = "CDD6F4"    # text colour
ALT_ROW_BG  = "181825"    # alternating row shade
NORMAL_BG   = "1E1E2E"


def export(leads: Sequence[dict], output_path: str) -> str:
    """
    Write *leads* to *output_path* (.xlsx).
    Returns the absolute path of the created file.
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads"

    thin = Side(style="thin", color="313244")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # ------------------------------------------------------------------ header
    header_font = Font(name="Calibri", bold=True, color=HEADER_FG, size=11)
    header_fill = PatternFill("solid", fgColor=HEADER_BG)
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for col_idx, (label, _, width) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=label)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = border
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    ws.row_dimensions[1].height = 22
    ws.freeze_panes = "A2"

    # ------------------------------------------------------------------ rows
    data_align = Alignment(vertical="top", wrap_text=True)
    normal_font = Font(name="Calibri", size=10, color="CDD6F4")

    for row_idx, lead in enumerate(leads, start=2):
        bg = ALT_ROW_BG if row_idx % 2 == 0 else NORMAL_BG
        row_fill = PatternFill("solid", fgColor=bg)

        for col_idx, (_, key, _) in enumerate(COLUMNS, start=1):
            value = lead.get(key, "") or ""
            cell = ws.cell(row=row_idx, column=col_idx, value=str(value))
            cell.font = normal_font
            cell.fill = row_fill
            cell.alignment = data_align
            cell.border = border

    # ------------------------------------------------------------------ meta
    ws.sheet_view.showGridLines = False
    wb.properties.title = "Darklightz Lead Generator Export"
    wb.properties.creator = "Darklightz Studio"
    wb.properties.created = datetime.now()

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    wb.save(output_path)
    return os.path.abspath(output_path)
