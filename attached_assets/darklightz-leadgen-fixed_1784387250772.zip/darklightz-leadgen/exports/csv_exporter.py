"""
Export leads to CSV using Python's built-in csv module — zero dependencies.
"""

from __future__ import annotations
import csv
import os
from typing import Sequence


HEADERS = [
    "Business Name", "Phone", "WhatsApp", "Instagram", "Facebook",
    "Address", "Rating", "Reviews", "Lead Type", "Status",
    "City", "Keyword", "Notes", "Created At",
]

KEYS = [
    "name", "phone", "whatsapp", "instagram", "facebook",
    "address", "rating", "reviews", "lead_type", "status",
    "city", "keyword", "notes", "created_at",
]


def export(leads: Sequence[dict], output_path: str) -> str:
    """
    Write *leads* to a UTF-8 CSV file at *output_path*.
    Returns the absolute path of the created file.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(HEADERS)
        for lead in leads:
            writer.writerow([str(lead.get(k, "") or "") for k in KEYS])

    return os.path.abspath(output_path)
