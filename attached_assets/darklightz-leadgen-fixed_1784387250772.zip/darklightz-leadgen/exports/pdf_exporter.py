"""
Export leads to a PDF using reportlab — free, open-source.
Generates a styled landscape table that mirrors the lead table.

Bug fixed vs original
---------------------
* "ROWBACKGROUND" is NOT a valid ReportLab TableStyle command and caused
  either a silent no-op or an AttributeError depending on the version.
  Replaced with the correct per-row "BACKGROUND" commands already built
  in row_bg_cmds.  Removed the duplicate invalid header entry.
* TA_CENTER was imported but never used — removed.
"""

from __future__ import annotations
import os
from datetime import datetime
from typing import Sequence

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, HRFlowable,
)
from reportlab.lib.enums import TA_LEFT


# --------------------------------------------------------------------------
# Colour palette (dark theme converted to reportlab colours)
# --------------------------------------------------------------------------
C_DARK    = colors.HexColor("#1E1E2E")
C_SURFACE = colors.HexColor("#313244")
C_ACCENT  = colors.HexColor("#CBA6F7")
C_TEXT    = colors.HexColor("#CDD6F4")
C_SUBTEXT = colors.HexColor("#A6ADC8")
C_ALT     = colors.HexColor("#181825")


COLUMNS = [
    ("Business Name", "name",      55 * mm),
    ("Phone",         "phone",     30 * mm),
    ("Address",       "address",   55 * mm),
    ("Rating",        "rating",    15 * mm),
    ("Lead Type",     "lead_type", 30 * mm),
    ("Status",        "status",    25 * mm),
    ("Notes",         "notes",     50 * mm),
]


def export(leads: Sequence[dict], output_path: str, title: str = "Lead Report") -> str:
    """
    Render *leads* to a PDF at *output_path*.
    Returns the absolute path of the created file.
    """
    out_dir = os.path.dirname(os.path.abspath(output_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    doc = SimpleDocTemplate(
        output_path,
        pagesize=landscape(A4),
        leftMargin=10 * mm,
        rightMargin=10 * mm,
        topMargin=12 * mm,
        bottomMargin=10 * mm,
        title=title,
        author="Darklightz Studio",
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "DLTitle",
        parent=styles["Title"],
        textColor=C_ACCENT,
        fontSize=16,
        spaceAfter=4,
        alignment=TA_LEFT,
        fontName="Helvetica-Bold",
    )
    sub_style = ParagraphStyle(
        "DLSub",
        parent=styles["Normal"],
        textColor=C_SUBTEXT,
        fontSize=9,
        spaceAfter=8,
        alignment=TA_LEFT,
        fontName="Helvetica",
    )
    cell_style = ParagraphStyle(
        "DLCell",
        parent=styles["Normal"],
        textColor=C_TEXT,
        fontSize=7.5,
        fontName="Helvetica",
        leading=10,
    )

    elements = []

    # Title block
    elements.append(Paragraph("Darklightz Lead Generator", title_style))
    elements.append(Paragraph(
        f"{title}  ·  {len(leads):,} leads  ·  "
        f"{datetime.now().strftime('%d %b %Y %H:%M')}",
        sub_style,
    ))
    elements.append(HRFlowable(
        width="100%", thickness=1, color=C_SURFACE, spaceAfter=6
    ))

    # Build table data
    col_labels = [col[0] for col in COLUMNS]
    col_keys   = [col[1] for col in COLUMNS]
    col_widths = [col[2] for col in COLUMNS]

    table_data = [col_labels]  # header row (plain strings — styled via TableStyle)

    for lead in leads:
        row = [
            Paragraph(str(lead.get(key, "") or ""), cell_style)
            for key in col_keys
        ]
        table_data.append(row)

    tbl = Table(table_data, colWidths=col_widths, repeatRows=1)

    # Build alternating-row background commands (valid BACKGROUND commands)
    row_count = len(table_data)
    row_bg_cmds = [
        ("BACKGROUND", (0, i), (-1, i), C_ALT if i % 2 == 0 else C_DARK)
        for i in range(1, row_count)
    ]

    tbl.setStyle(TableStyle([
        # ---- Header ----
        ("BACKGROUND",  (0, 0), (-1, 0), C_SURFACE),
        ("TEXTCOLOR",   (0, 0), (-1, 0), C_ACCENT),
        ("FONTNAME",    (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",    (0, 0), (-1, 0), 8),
        ("ALIGN",       (0, 0), (-1, 0), "CENTER"),
        ("VALIGN",      (0, 0), (-1, 0), "MIDDLE"),
        # ---- Body ----
        ("FONTNAME",    (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",    (0, 1), (-1, -1), 7.5),
        ("VALIGN",      (0, 1), (-1, -1), "TOP"),
        ("TEXTCOLOR",   (0, 1), (-1, -1), C_TEXT),
        # ---- Grid ----
        ("GRID",        (0, 0), (-1, -1), 0.3, C_SURFACE),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING",(0, 0), (-1, -1), 3),
        ("TOPPADDING",  (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 3),
        # ---- Alternating rows ----
        *row_bg_cmds,
    ]))

    elements.append(tbl)
    doc.build(elements)
    return os.path.abspath(output_path)
