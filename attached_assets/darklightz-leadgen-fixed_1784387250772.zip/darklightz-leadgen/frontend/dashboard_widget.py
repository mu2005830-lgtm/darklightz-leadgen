"""
Dashboard widget — shows aggregate stats and recent activity.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QFrame, QGridLayout, QScrollArea,
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont

from database.operations import get_dashboard_stats


class StatCard(QFrame):
    """A single metric tile shown on the dashboard."""

    def __init__(self, label: str, value: str = "0", colour: str = "#cba6f7"):
        super().__init__()
        self.setObjectName("StatCard")
        self.setMinimumSize(150, 90)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(4)

        self._value_lbl = QLabel(value)
        self._value_lbl.setObjectName("StatValue")
        font = QFont()
        font.setPointSize(26)
        font.setBold(True)
        self._value_lbl.setFont(font)
        self._value_lbl.setStyleSheet(f"color: {colour};")

        label_lbl = QLabel(label)
        label_lbl.setObjectName("StatLabel")
        label_lbl.setWordWrap(True)

        layout.addWidget(self._value_lbl)
        layout.addWidget(label_lbl)

    def update_value(self, value: str) -> None:
        self._value_lbl.setText(str(value))


class DashboardWidget(QWidget):
    """Full dashboard page."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cards: dict[str, StatCard] = {}
        self._build_ui()

        # Auto-refresh every 5 s
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(5000)

        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(0)

        # Page heading
        title = QLabel("Dashboard")
        title.setObjectName("PageTitle")
        subtitle = QLabel("Overview of your lead generation activity")
        subtitle.setObjectName("PageSubtitle")
        outer.addWidget(title)
        outer.addWidget(subtitle)

        # Scrollable area so it works on small screens
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        container = QWidget()
        scroll.setWidget(container)
        vbox = QVBoxLayout(container)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(20)

        # ---- Stat cards row 1 ----------------------------------------
        metrics = [
            ("total_leads",   "Total Leads",     "#cba6f7"),
            ("no_website",    "No Website",       "#f38ba8"),
            ("social_only",   "Social Only",      "#f9e2af"),
            ("total_searches","Searches Run",     "#89b4fa"),
        ]
        grid = QGridLayout()
        grid.setSpacing(12)
        for col, (key, label, colour) in enumerate(metrics):
            card = StatCard(label, "0", colour)
            self._cards[key] = card
            grid.addWidget(card, 0, col)
        vbox.addLayout(grid)

        # ---- Status breakdown -----------------------------------------
        status_label = QLabel("Lead Status Breakdown")
        status_label.setObjectName("PageTitle")
        font = status_label.font()
        font.setPointSize(13)
        status_label.setFont(font)
        vbox.addWidget(status_label)

        status_metrics = [
            ("new_leads",  "New",       "#cba6f7"),
            ("contacted",  "Contacted", "#89b4fa"),
            ("interested", "Interested","#a6e3a1"),
            ("closed",     "Closed",    "#a6adc8"),
        ]
        status_grid = QGridLayout()
        status_grid.setSpacing(12)
        for col, (key, label, colour) in enumerate(status_metrics):
            card = StatCard(label, "0", colour)
            self._cards[key] = card
            status_grid.addWidget(card, 0, col)
        vbox.addLayout(status_grid)

        # ---- Recent searches ------------------------------------------
        recent_label = QLabel("Recent Searches")
        recent_label.setObjectName("PageTitle")
        recent_label.setFont(font)
        vbox.addWidget(recent_label)

        self._recent_frame = QVBoxLayout()
        self._recent_frame.setSpacing(6)
        vbox.addLayout(self._recent_frame)
        vbox.addStretch()

        outer.addWidget(scroll)

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        """Pull fresh stats from the database and update the UI."""
        stats = get_dashboard_stats()

        for key, card in self._cards.items():
            card.update_value(str(stats.get(key, 0)))

        # Rebuild recent searches list
        while self._recent_frame.count():
            item = self._recent_frame.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for s in stats.get("recent_searches", []):
            row = QFrame()
            row.setObjectName("StatCard")
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(12, 8, 12, 8)

            kw = QLabel(f"🔍  {s['keyword']}  in  {s['city']}")
            kw.setStyleSheet("color: #cdd6f4; font-weight: bold;")
            ts = QLabel(s.get("created_at", ""))
            ts.setStyleSheet("color: #6c7086; font-size: 11px;")
            ts.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

            row_layout.addWidget(kw)
            row_layout.addStretch()
            row_layout.addWidget(ts)
            self._recent_frame.addWidget(row)
