"""
Settings widget — application preferences stored in SQLite.

Bugs fixed vs original
-----------------------
* QFrame imported but never used — removed.
* Qt imported but never used — removed.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QGroupBox,
    QCheckBox, QSpinBox, QFileDialog, QMessageBox,
)

from database import operations as db
from database.models import get_connection


class SettingsWidget(QWidget):
    """Settings page."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
        self._load()

    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(0)

        title = QLabel("Settings")
        title.setObjectName("PageTitle")
        subtitle = QLabel("Configure scraper behaviour and export preferences.")
        subtitle.setObjectName("PageSubtitle")
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(16)

        # ---- Scraper settings ----------------------------------------
        scraper_group = QGroupBox("Scraper")
        sg = QVBoxLayout(scraper_group)
        sg.setSpacing(12)

        self._headless_cb = QCheckBox(
            "Run Chromium in background (headless mode — faster)"
        )
        sg.addWidget(self._headless_cb)

        delay_row = QHBoxLayout()
        delay_lbl = QLabel("Scroll delay between pages (ms):")
        delay_lbl.setObjectName("FormLabel")
        self._scroll_delay = QSpinBox()
        self._scroll_delay.setRange(500, 10_000)
        self._scroll_delay.setSingleStep(250)
        self._scroll_delay.setFixedWidth(110)
        delay_row.addWidget(delay_lbl)
        delay_row.addWidget(self._scroll_delay)
        delay_row.addStretch()
        sg.addLayout(delay_row)

        timeout_row = QHBoxLayout()
        timeout_lbl = QLabel("Page load timeout (ms):")
        timeout_lbl.setObjectName("FormLabel")
        self._page_timeout = QSpinBox()
        self._page_timeout.setRange(5_000, 120_000)
        self._page_timeout.setSingleStep(5_000)
        self._page_timeout.setFixedWidth(110)
        timeout_row.addWidget(timeout_lbl)
        timeout_row.addWidget(self._page_timeout)
        timeout_row.addStretch()
        sg.addLayout(timeout_row)

        layout.addWidget(scraper_group)
        layout.addSpacing(14)

        # ---- Export settings -----------------------------------------
        export_group = QGroupBox("Export")
        eg = QVBoxLayout(export_group)
        eg.setSpacing(12)

        dir_row = QHBoxLayout()
        dir_lbl = QLabel("Default export folder:")
        dir_lbl.setObjectName("FormLabel")
        self._export_dir = QLineEdit()
        self._export_dir.setPlaceholderText("Leave empty to use Downloads folder")
        browse_btn = QPushButton("Browse…")
        browse_btn.setObjectName("SecondaryButton")
        browse_btn.setFixedWidth(90)
        browse_btn.clicked.connect(self._browse_dir)
        dir_row.addWidget(dir_lbl)
        dir_row.addWidget(self._export_dir, 1)
        dir_row.addWidget(browse_btn)
        eg.addLayout(dir_row)

        layout.addWidget(export_group)
        layout.addSpacing(16)

        # ---- Data management -----------------------------------------
        danger_group = QGroupBox("Data Management")
        dg = QVBoxLayout(danger_group)
        dg.setSpacing(10)

        danger_lbl = QLabel("⚠  These actions are permanent and cannot be undone.")
        danger_lbl.setStyleSheet("color: #f38ba8;")
        dg.addWidget(danger_lbl)

        del_row = QHBoxLayout()
        del_row.setSpacing(12)

        del_all_btn = QPushButton("Delete ALL Leads")
        del_all_btn.setObjectName("DangerButton")
        del_all_btn.clicked.connect(self._delete_all_leads)

        del_searches_btn = QPushButton("Delete Search History")
        del_searches_btn.setObjectName("DangerButton")
        del_searches_btn.clicked.connect(self._delete_searches)

        del_row.addWidget(del_all_btn)
        del_row.addWidget(del_searches_btn)
        del_row.addStretch()
        dg.addLayout(del_row)

        layout.addWidget(danger_group)
        layout.addSpacing(16)

        # ---- Save button ---------------------------------------------
        save_row = QHBoxLayout()
        save_btn = QPushButton("💾  Save Settings")
        save_btn.setFixedWidth(160)
        save_btn.clicked.connect(self._save)
        save_row.addStretch()
        save_row.addWidget(save_btn)
        layout.addLayout(save_row)

        self._status_lbl = QLabel("")
        self._status_lbl.setStyleSheet("color: #a6e3a1; font-size: 12px;")
        layout.addWidget(self._status_lbl)
        layout.addStretch()

    # ------------------------------------------------------------------

    def _load(self) -> None:
        s = db.get_all_settings()
        self._headless_cb.setChecked(s.get("headless", "1") == "1")
        self._scroll_delay.setValue(int(s.get("scroll_delay", 1500)))
        self._page_timeout.setValue(int(s.get("page_timeout", 30_000)))
        self._export_dir.setText(s.get("export_dir", ""))

    def _save(self) -> None:
        db.set_setting("headless",     "1" if self._headless_cb.isChecked() else "0")
        db.set_setting("scroll_delay", str(self._scroll_delay.value()))
        db.set_setting("page_timeout", str(self._page_timeout.value()))
        db.set_setting("export_dir",   self._export_dir.text().strip())
        self._status_lbl.setText("✅  Settings saved.")

    def _browse_dir(self) -> None:
        directory = QFileDialog.getExistingDirectory(
            self, "Select Export Folder", self._export_dir.text()
        )
        if directory:
            self._export_dir.setText(directory)

    def _delete_all_leads(self) -> None:
        reply = QMessageBox.question(
            self, "Delete All Leads",
            "Permanently delete ALL leads?\nThis cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            conn = get_connection()
            with conn:
                conn.execute("DELETE FROM leads")
            conn.close()
            self._status_lbl.setText("🗑  All leads deleted.")

    def _delete_searches(self) -> None:
        reply = QMessageBox.question(
            self, "Delete Search History",
            "Delete all search sessions?\n"
            "This will also cascade-delete all their leads.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            conn = get_connection()
            with conn:
                conn.execute("DELETE FROM searches")
            conn.close()
            self._status_lbl.setText("🗑  Search history deleted.")
