"""
Search widget — the "Start Search" form that kicks off a scraping session.

Bugs fixed vs original
-----------------------
* `from database.models import init_db` imported but never used — removed.
* `self._found` set but never read (scraper tracks its own count) — removed.
* `self._max` used in signal handlers but not initialised in __init__,
  so a stale signal after a crash could raise AttributeError — fixed by
  initialising to 0 in __init__.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QSpinBox, QPushButton, QProgressBar,
    QTextEdit, QGroupBox, QCheckBox,
)
from PyQt6.QtCore import Qt, pyqtSignal

from backend.scraper import ScraperWorker
from database import operations as db
from utilities.logger import logger


class SearchWidget(QWidget):
    """Lead search form + real-time progress log."""

    # Emitted whenever a new lead has been inserted into the DB
    leads_updated = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker: ScraperWorker | None = None
        self._search_id: int | None = None
        self._max: int = 0          # initialised here so signal handlers are safe
        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(0)

        title = QLabel("Lead Search")
        title.setObjectName("PageTitle")
        subtitle = QLabel(
            "Enter your search criteria and click Start Search. "
            "Only businesses without a real website are collected."
        )
        subtitle.setObjectName("PageSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(12)

        # ---- Search form group ----------------------------------------
        form_group = QGroupBox("Search Parameters")
        form_layout = QVBoxLayout(form_group)
        form_layout.setSpacing(12)

        # Row 1: Keyword + City
        row1 = QHBoxLayout()
        row1.setSpacing(16)

        kw_col = QVBoxLayout()
        kw_lbl = QLabel("Business Keyword")
        kw_lbl.setObjectName("FormLabel")
        self._keyword_input = QLineEdit()
        self._keyword_input.setPlaceholderText("e.g. Restaurant, Salon, Gym ...")
        kw_col.addWidget(kw_lbl)
        kw_col.addWidget(self._keyword_input)

        city_col = QVBoxLayout()
        city_lbl = QLabel("City / Location")
        city_lbl.setObjectName("FormLabel")
        self._city_input = QLineEdit()
        self._city_input.setPlaceholderText("e.g. Lahore, Karachi, Islamabad ...")
        city_col.addWidget(city_lbl)
        city_col.addWidget(self._city_input)

        row1.addLayout(kw_col, 2)
        row1.addLayout(city_col, 2)
        form_layout.addLayout(row1)

        # Row 2: Count + Options
        row2 = QHBoxLayout()
        row2.setSpacing(16)

        count_col = QVBoxLayout()
        count_lbl = QLabel("Number of Leads")
        count_lbl.setObjectName("FormLabel")
        self._count_spin = QSpinBox()
        self._count_spin.setRange(1, 2000)
        self._count_spin.setValue(50)
        self._count_spin.setSingleStep(10)
        count_col.addWidget(count_lbl)
        count_col.addWidget(self._count_spin)

        opts_col = QVBoxLayout()
        opts_lbl = QLabel("Options")
        opts_lbl.setObjectName("FormLabel")
        self._headless_cb = QCheckBox("Run browser in background (headless)")
        self._headless_cb.setChecked(True)
        opts_col.addWidget(opts_lbl)
        opts_col.addWidget(self._headless_cb)

        row2.addLayout(count_col, 1)
        row2.addLayout(opts_col, 3)
        form_layout.addLayout(row2)

        layout.addWidget(form_group)
        layout.addSpacing(12)

        # ---- Buttons -------------------------------------------------
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        self._start_btn = QPushButton("▶  Start Search")
        self._start_btn.setMinimumHeight(40)
        self._start_btn.clicked.connect(self._start_search)

        self._stop_btn = QPushButton("■  Stop")
        self._stop_btn.setObjectName("StopButton")
        self._stop_btn.setMinimumHeight(40)
        self._stop_btn.setEnabled(False)
        self._stop_btn.clicked.connect(self._stop_search)

        btn_row.addWidget(self._start_btn, 3)
        btn_row.addWidget(self._stop_btn, 1)
        layout.addLayout(btn_row)
        layout.addSpacing(12)

        # ---- Progress ------------------------------------------------
        self._progress_bar = QProgressBar()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setTextVisible(True)
        self._progress_bar.setFormat("Ready")
        layout.addWidget(self._progress_bar)
        layout.addSpacing(8)

        self._status_lbl = QLabel("Ready to search.")
        self._status_lbl.setStyleSheet("color: #a6adc8; font-size: 12px;")
        layout.addWidget(self._status_lbl)
        layout.addSpacing(8)

        # ---- Activity log --------------------------------------------
        log_group = QGroupBox("Activity Log")
        log_layout = QVBoxLayout(log_group)
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setPlaceholderText("Search activity will appear here ...")
        self._log.setMaximumHeight(250)
        log_layout.addWidget(self._log)

        clear_btn = QPushButton("Clear Log")
        clear_btn.setObjectName("SecondaryButton")
        clear_btn.setFixedWidth(100)
        clear_btn.clicked.connect(self._log.clear)
        log_layout.addWidget(clear_btn, alignment=Qt.AlignmentFlag.AlignRight)

        layout.addWidget(log_group)
        layout.addStretch()

    # ------------------------------------------------------------------
    # Search control
    # ------------------------------------------------------------------

    def _start_search(self) -> None:
        keyword = self._keyword_input.text().strip()
        city    = self._city_input.text().strip()
        count   = self._count_spin.value()

        if not keyword:
            self._status_lbl.setText("⚠  Please enter a business keyword.")
            return
        if not city:
            self._status_lbl.setText("⚠  Please enter a city or location.")
            return

        self._search_id = db.create_search(keyword, city, count)
        self._max       = count

        self._log.clear()
        self._log_line(f"Starting search: {keyword!r} in {city!r} | max {count} leads")
        self._status_lbl.setText("Searching…")
        self._progress_bar.setRange(0, count)
        self._progress_bar.setValue(0)
        self._progress_bar.setFormat(f"0 / {count}")

        headless     = self._headless_cb.isChecked()
        scroll_delay = int(db.get_setting("scroll_delay", "1500"))
        page_timeout = int(db.get_setting("page_timeout", "30000"))

        self._worker = ScraperWorker(
            keyword=keyword,
            city=city,
            max_leads=count,
            search_id=self._search_id,
            headless=headless,
            scroll_delay=scroll_delay,
            page_timeout=page_timeout,
        )
        self._worker.progress.connect(self._on_progress)
        self._worker.lead_found.connect(self._on_lead_found)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

        self._start_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)

        logger.info("Search started: keyword=%r city=%r max=%d", keyword, city, count)

    def _stop_search(self) -> None:
        if self._worker and self._worker.isRunning():
            self._worker.stop()
            self._log_line("Stop requested — finishing current item…")
            self._stop_btn.setEnabled(False)

    # ------------------------------------------------------------------
    # Worker signal handlers
    # ------------------------------------------------------------------

    def _on_progress(self, count: int, msg: str) -> None:
        self._progress_bar.setValue(count)
        self._progress_bar.setFormat(f"{count} / {self._max}")
        self._status_lbl.setText(msg)
        self._log_line(msg)

    def _on_lead_found(self, data: dict) -> None:
        inserted = db.insert_lead(data)
        if inserted:
            self._log_line(
                f"✅  Saved: {data.get('name', '?')}  [{data.get('lead_type', '')}]"
            )
            self.leads_updated.emit()
        else:
            self._log_line(f"⚠  Duplicate skipped: {data.get('name', '?')}")

    def _on_finished(self, total: int, stopped_early: bool) -> None:
        if self._search_id:
            status = "stopped" if stopped_early else "complete"
            db.complete_search(self._search_id, status)

        self._start_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)

        if stopped_early:
            msg = f"Search stopped — {total} leads saved so far."
        else:
            msg = f"Search complete — {total} qualifying leads found."

        self._status_lbl.setText(msg)
        self._log_line(f"{'🛑' if stopped_early else '✔️'} {msg}")
        self._progress_bar.setFormat(f"{total} / {self._max}")
        self.leads_updated.emit()
        logger.info("Search finished: total=%d stopped_early=%s", total, stopped_early)

    def _on_error(self, msg: str) -> None:
        self._start_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        self._status_lbl.setText(f"❌  Error: {msg}")
        self._log_line(f"❌  Error: {msg}")
        logger.error("Scraper error reported to UI: %s", msg)

    # ------------------------------------------------------------------
    # Logging helper
    # ------------------------------------------------------------------

    def _log_line(self, text: str) -> None:
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M:%S")
        self._log.append(f"[{ts}]  {text}")
        sb = self._log.verticalScrollBar()
        sb.setValue(sb.maximum())
