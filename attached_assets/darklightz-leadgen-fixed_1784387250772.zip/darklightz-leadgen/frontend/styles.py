"""
Catppuccin Mocha-inspired dark QSS stylesheet for Darklightz Lead Generator.
"""

DARK_THEME = """
/* =====================================================================
   Global
   ===================================================================== */

QWidget {
    background-color: #1e1e2e;
    color: #cdd6f4;
    font-family: "Segoe UI", "Inter", sans-serif;
    font-size: 13px;
}

QMainWindow {
    background-color: #181825;
}

/* =====================================================================
   Sidebar / Nav
   ===================================================================== */

#Sidebar {
    background-color: #181825;
    border-right: 1px solid #313244;
    min-width: 200px;
    max-width: 220px;
}

#NavButton {
    background-color: transparent;
    color: #a6adc8;
    border: none;
    border-radius: 8px;
    padding: 10px 14px;
    text-align: left;
    font-size: 13px;
    margin: 2px 8px;
}

#NavButton:hover {
    background-color: #313244;
    color: #cdd6f4;
}

#NavButton[active="true"] {
    background-color: #313244;
    color: #cba6f7;
    font-weight: bold;
    border-left: 3px solid #cba6f7;
}

#AppTitle {
    color: #cba6f7;
    font-size: 16px;
    font-weight: bold;
    padding: 16px 14px 8px 14px;
}

#AppSubtitle {
    color: #6c7086;
    font-size: 10px;
    padding: 0px 14px 12px 14px;
}

#SidebarDivider {
    background-color: #313244;
    max-height: 1px;
    min-height: 1px;
    margin: 4px 12px;
}

/* =====================================================================
   Stat Cards (Dashboard)
   ===================================================================== */

#StatCard {
    background-color: #313244;
    border-radius: 10px;
    padding: 16px;
    border: 1px solid #45475a;
}

#StatValue {
    color: #cba6f7;
    font-size: 28px;
    font-weight: bold;
}

#StatLabel {
    color: #a6adc8;
    font-size: 11px;
}

/* =====================================================================
   Page Headers
   ===================================================================== */

#PageTitle {
    font-size: 20px;
    font-weight: bold;
    color: #cdd6f4;
    padding-bottom: 4px;
}

#PageSubtitle {
    font-size: 12px;
    color: #6c7086;
    padding-bottom: 12px;
}

/* =====================================================================
   Buttons
   ===================================================================== */

QPushButton {
    background-color: #cba6f7;
    color: #1e1e2e;
    border: none;
    border-radius: 7px;
    padding: 8px 20px;
    font-size: 13px;
    font-weight: bold;
    min-height: 34px;
}

QPushButton:hover {
    background-color: #d4b5f8;
}

QPushButton:pressed {
    background-color: #b891f5;
}

QPushButton:disabled {
    background-color: #45475a;
    color: #6c7086;
}

QPushButton#SecondaryButton {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    font-weight: normal;
}

QPushButton#SecondaryButton:hover {
    background-color: #45475a;
}

QPushButton#DangerButton {
    background-color: #f38ba8;
    color: #1e1e2e;
}

QPushButton#DangerButton:hover {
    background-color: #f5a1b8;
}

QPushButton#StopButton {
    background-color: #f38ba8;
    color: #1e1e2e;
}

QPushButton#ExportButton {
    background-color: #a6e3a1;
    color: #1e1e2e;
}

QPushButton#ExportButton:hover {
    background-color: #b8eab4;
}

/* =====================================================================
   Inputs
   ===================================================================== */

QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 7px;
    padding: 6px 10px;
    selection-background-color: #cba6f7;
    selection-color: #1e1e2e;
    min-height: 32px;
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus {
    border: 1px solid #cba6f7;
}

QComboBox::drop-down {
    border: none;
    width: 24px;
}

QComboBox::down-arrow {
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 6px solid #a6adc8;
    margin-right: 6px;
}

QComboBox QAbstractItemView {
    background-color: #313244;
    color: #cdd6f4;
    selection-background-color: #cba6f7;
    selection-color: #1e1e2e;
    border: 1px solid #45475a;
    border-radius: 7px;
    outline: none;
}

QSpinBox::up-button, QSpinBox::down-button {
    background-color: #45475a;
    border: none;
    border-radius: 4px;
    width: 16px;
}

QSpinBox::up-arrow {
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-bottom: 5px solid #cdd6f4;
}

QSpinBox::down-arrow {
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid #cdd6f4;
}

/* =====================================================================
   Table
   ===================================================================== */

QTableWidget {
    background-color: #1e1e2e;
    gridline-color: #313244;
    border: none;
    border-radius: 8px;
    alternate-background-color: #181825;
    selection-background-color: #45475a;
    selection-color: #cdd6f4;
}

QTableWidget::item {
    padding: 6px 8px;
    border: none;
}

QTableWidget::item:selected {
    background-color: #45475a;
    color: #cdd6f4;
}

QHeaderView::section {
    background-color: #181825;
    color: #a6adc8;
    border: none;
    border-right: 1px solid #313244;
    border-bottom: 1px solid #313244;
    padding: 8px 8px;
    font-weight: bold;
    font-size: 12px;
}

QHeaderView::section:first {
    border-left: none;
}

/* =====================================================================
   Scrollbars
   ===================================================================== */

QScrollBar:vertical {
    background-color: #181825;
    width: 8px;
    border-radius: 4px;
}

QScrollBar::handle:vertical {
    background-color: #45475a;
    border-radius: 4px;
    min-height: 30px;
}

QScrollBar::handle:vertical:hover {
    background-color: #585b70;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar:horizontal {
    background-color: #181825;
    height: 8px;
    border-radius: 4px;
}

QScrollBar::handle:horizontal {
    background-color: #45475a;
    border-radius: 4px;
    min-width: 30px;
}

QScrollBar::handle:horizontal:hover {
    background-color: #585b70;
}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0px;
}

/* =====================================================================
   Labels
   ===================================================================== */

QLabel {
    color: #cdd6f4;
    background: transparent;
}

QLabel#FormLabel {
    color: #a6adc8;
    font-size: 12px;
    font-weight: bold;
}

/* =====================================================================
   Progress Bar
   ===================================================================== */

QProgressBar {
    background-color: #313244;
    border-radius: 6px;
    border: none;
    text-align: center;
    color: #cdd6f4;
    font-size: 11px;
    height: 14px;
}

QProgressBar::chunk {
    background-color: #cba6f7;
    border-radius: 6px;
}

/* =====================================================================
   Group Box
   ===================================================================== */

QGroupBox {
    border: 1px solid #313244;
    border-radius: 8px;
    margin-top: 8px;
    padding-top: 8px;
    color: #a6adc8;
    font-size: 12px;
    font-weight: bold;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: #cba6f7;
}

/* =====================================================================
   Tabs
   ===================================================================== */

QTabWidget::pane {
    border: 1px solid #313244;
    border-radius: 8px;
    background-color: #1e1e2e;
}

QTabBar::tab {
    background-color: #181825;
    color: #a6adc8;
    border: none;
    padding: 8px 18px;
    margin-right: 2px;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
}

QTabBar::tab:selected {
    background-color: #313244;
    color: #cba6f7;
    font-weight: bold;
}

QTabBar::tab:hover {
    background-color: #313244;
    color: #cdd6f4;
}

/* =====================================================================
   Tooltip
   ===================================================================== */

QToolTip {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 5px;
    padding: 4px 8px;
    font-size: 12px;
}

/* =====================================================================
   Status bar
   ===================================================================== */

QStatusBar {
    background-color: #181825;
    color: #6c7086;
    font-size: 11px;
    border-top: 1px solid #313244;
}

/* =====================================================================
   Checkbox
   ===================================================================== */

QCheckBox {
    color: #cdd6f4;
    spacing: 8px;
}

QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 2px solid #45475a;
    background-color: #313244;
}

QCheckBox::indicator:checked {
    background-color: #cba6f7;
    border-color: #cba6f7;
}

/* =====================================================================
   Splitter
   ===================================================================== */

QSplitter::handle {
    background-color: #313244;
}

/* =====================================================================
   Message Box
   ===================================================================== */

QMessageBox {
    background-color: #1e1e2e;
    color: #cdd6f4;
}

QMessageBox QPushButton {
    min-width: 80px;
}

/* =====================================================================
   Context Menu
   ===================================================================== */

QMenu {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 8px;
    padding: 4px;
}

QMenu::item {
    padding: 7px 20px;
    border-radius: 5px;
    margin: 1px;
}

QMenu::item:selected {
    background-color: #45475a;
    color: #cdd6f4;
}

QMenu::separator {
    height: 1px;
    background-color: #45475a;
    margin: 4px 8px;
}
"""


STATUS_COLOURS = {
    "New":           "#cba6f7",   # purple
    "Contacted":     "#89b4fa",   # blue
    "Follow-up":     "#fab387",   # peach
    "Interested":    "#a6e3a1",   # green
    "Closed":        "#a6adc8",   # grey
    "Not Interested":"#f38ba8",   # red
}

LEAD_TYPE_COLOURS = {
    "No Website":          "#f38ba8",
    "No Online Presence":  "#fab387",
    "Facebook Only":       "#89b4fa",
    "Instagram Only":      "#f2cdcd",
    "WhatsApp Only":       "#a6e3a1",
    "Social Only":         "#f9e2af",
}
