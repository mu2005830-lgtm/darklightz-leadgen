"""
Main application window — Darklightz Studio Lead Generation Suite.

Layout
------
    ┌──────────┬──────────────────────────────────────┐
    │ Sidebar  │  Content area (stacked pages)         │
    │          │                                       │
    │          │                                       │
    │          ├──────────────────────────────────────┤
    │          │  footer: "Developed by Darklightz…"  │
    └──────────┴──────────────────────────────────────┘
"""

from __future__ import annotations

import os
import sys

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QStackedWidget, QSizePolicy,
    QStatusBar, QFrame,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon, QFont, QCloseEvent, QPixmap

from frontend.dashboard_widget import DashboardWidget
from frontend.search_widget    import SearchWidget
from frontend.leads_widget     import LeadsWidget
from frontend.export_widget    import ExportWidget
from frontend.settings_widget  import SettingsWidget
from frontend.about_widget     import AboutWidget
from utilities.logger import logger

# ---------------------------------------------------------------------------
# Asset resolution
# ---------------------------------------------------------------------------
if getattr(sys, "frozen", False):
    _BASE = sys._MEIPASS
else:
    _BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_LOGO_PATH = os.path.join(_BASE, "assets", "logo.png")
_ICON_PATH = os.path.join(_BASE, "assets", "icon.ico")

# ---------------------------------------------------------------------------
# Nav item spec
# ---------------------------------------------------------------------------
NAV_ITEMS = [
    ("Dashboard",   "⬛", 0),
    ("Lead Search", "🔍", 1),
    ("Lead Table",  "📋", 2),
    ("Export",      "📤", 3),
    ("Settings",    "⚙",  4),
    ("About",       "ℹ",  5),
]


class NavButton(QPushButton):
    """Sidebar navigation button with active-state styling."""

    def __init__(self, label: str, icon_char: str):
        super().__init__(f"  {icon_char}   {label}")
        self.setObjectName("NavButton")
        self.setCheckable(False)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setProperty("active", False)
        self.setMinimumHeight(40)
        font = QFont()
        font.setPointSize(11)
        self.setFont(font)

    def set_active(self, active: bool) -> None:
        self.setProperty("active", active)
        self.style().unpolish(self)
        self.style().polish(self)


class MainWindow(QMainWindow):
    """Top-level application window."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Darklightz Studio — Lead Generation Suite")
        self.setMinimumSize(1100, 680)
        self.resize(1280, 780)

        # Window icon
        for path in (_ICON_PATH, _LOGO_PATH):
            if os.path.exists(path):
                self.setWindowIcon(QIcon(path))
                break

        self._nav_buttons: list[NavButton] = []
        self._build_ui()
        self._navigate(0)

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)

        # ── Outer wrapper: sidebar | [content + footer] ────────────────
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Sidebar ────────────────────────────────────────────────────
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(0, 0, 0, 12)
        sidebar_layout.setSpacing(0)

        # Logo in sidebar
        if os.path.exists(_LOGO_PATH):
            logo_pix = QPixmap(_LOGO_PATH).scaledToWidth(
                64, Qt.TransformationMode.SmoothTransformation
            )
            logo_lbl = QLabel()
            logo_lbl.setPixmap(logo_pix)
            logo_lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            logo_lbl.setStyleSheet("padding: 14px 0 4px 0;")
            sidebar_layout.addWidget(logo_lbl)

        title_lbl = QLabel("Darklightz")
        title_lbl.setObjectName("AppTitle")
        subtitle_lbl = QLabel("Lead Generator")
        subtitle_lbl.setObjectName("AppSubtitle")
        sidebar_layout.addWidget(title_lbl)
        sidebar_layout.addWidget(subtitle_lbl)

        div = QFrame()
        div.setObjectName("SidebarDivider")
        div.setFrameShape(QFrame.Shape.HLine)
        sidebar_layout.addWidget(div)
        sidebar_layout.addSpacing(6)

        for label, icon, idx in NAV_ITEMS:
            btn = NavButton(label, icon)
            btn.clicked.connect(lambda _, i=idx: self._navigate(i))
            sidebar_layout.addWidget(btn)
            self._nav_buttons.append(btn)

        sidebar_layout.addStretch()

        ver = QLabel("v 1.0")
        ver.setStyleSheet("color: #313244; font-size: 10px; padding: 0 14px;")
        sidebar_layout.addWidget(ver)

        root.addWidget(sidebar)

        # ── Right panel: content stack + footer ────────────────────────
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        # Content pages
        self._stack = QStackedWidget()

        self._dashboard_page = DashboardWidget()
        self._search_page    = SearchWidget()
        self._leads_page     = LeadsWidget()
        self._export_page    = ExportWidget()
        self._settings_page  = SettingsWidget()
        self._about_page     = AboutWidget()

        for page in [
            self._dashboard_page,
            self._search_page,
            self._leads_page,
            self._export_page,
            self._settings_page,
            self._about_page,
        ]:
            self._stack.addWidget(page)

        right_layout.addWidget(self._stack, 1)

        # Footer strip
        footer = self._build_footer()
        right_layout.addWidget(footer)

        root.addWidget(right_panel, 1)

        # ── Status bar ─────────────────────────────────────────────────
        status_bar = QStatusBar()
        self.setStatusBar(status_bar)
        self._status_msg = QLabel("Ready")
        status_bar.addPermanentWidget(self._status_msg)

        # ── Signal wiring ──────────────────────────────────────────────
        self._search_page.leads_updated.connect(self._on_leads_updated)

    def _build_footer(self) -> QFrame:
        """Subtle footer bar with branding label."""
        footer = QFrame()
        footer.setFixedHeight(24)
        footer.setStyleSheet(
            "QFrame {"
            "  background: #11111b;"
            "  border-top: 1px solid #1e1e2e;"
            "}"
        )
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(12, 0, 12, 0)

        fl.addStretch()

        brand = QLabel("Developed by Darklightz Studio")
        brand.setStyleSheet(
            "color: #313244;"
            "font-size: 9px;"
            "letter-spacing: 1px;"
            "background: transparent;"
        )
        fl.addWidget(brand)

        return footer

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _navigate(self, index: int) -> None:
        self._stack.setCurrentIndex(index)
        for i, btn in enumerate(self._nav_buttons):
            btn.set_active(i == index)

        page_names = [label for label, _, _ in NAV_ITEMS]
        self._status_msg.setText(page_names[index])

        if index == 0:
            self._dashboard_page.refresh()
        if index == 2:
            self._leads_page.refresh()

    def _on_leads_updated(self) -> None:
        if self._stack.currentIndex() == 2:
            self._leads_page.refresh()

    # ------------------------------------------------------------------
    # Clean shutdown
    # ------------------------------------------------------------------

    def closeEvent(self, event: QCloseEvent) -> None:
        worker = getattr(self._search_page, "_worker", None)
        if worker is not None and worker.isRunning():
            logger.info("Window closing — stopping active scraper thread.")
            worker.stop()
            worker.wait(5000)

        logger.info("Application closing.")
        event.accept()
