"""
Leads Table widget — displays, filters, and allows inline editing of leads.

Bugs fixed vs original
-----------------------
* pyqtSignal imported but never used — removed.
* self._leads populated in refresh() but never read (apply_filters goes
  straight to DB) — removed the redundant assignment.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QComboBox, QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QDialog, QDialogButtonBox,
    QTextEdit, QMenu, QMessageBox,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QBrush, QAction

from database import operations as db
from frontend.styles import STATUS_COLOURS, LEAD_TYPE_COLOURS


# Column definitions: (header label, dict key, default width px)
COLUMNS = [
    ("Business Name", "name",      220),
    ("Phone",         "phone",      120),
    ("WhatsApp",      "whatsapp",   180),
    ("Instagram",     "instagram",  180),
    ("Facebook",      "facebook",   180),
    ("Address",       "address",    200),
    ("Rating",        "rating",      60),
    ("Reviews",       "reviews",     70),
    ("Lead Type",     "lead_type",  130),
    ("Status",        "status",     110),
    ("Notes",         "notes",      200),
]

STATUS_OPTIONS = ["New", "Contacted", "Follow-up", "Interested", "Closed", "Not Interested"]
ALL_STATUS     = ["All"] + STATUS_OPTIONS


class NotesDialog(QDialog):
    """Full notes editor for a single lead."""

    def __init__(self, lead_id: int, name: str, current_notes: str, parent=None):
        super().__init__(parent)
        self.lead_id = lead_id
        self.setWindowTitle(f"Notes — {name}")
        self.setMinimumSize(500, 380)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(10)

        lbl = QLabel("Notes (saved when you click Save)")
        lbl.setStyleSheet("color: #a6adc8; font-size: 12px;")
        layout.addWidget(lbl)

        self._editor = QTextEdit()
        self._editor.setPlainText(current_notes)
        self._editor.setPlaceholderText(
            "Write anything here — call notes, budget info, follow-up dates …"
        )
        layout.addWidget(self._editor)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save |
            QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._save)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _save(self) -> None:
        db.update_lead_notes(self.lead_id, self._editor.toPlainText())
        self.accept()


class LeadsWidget(QWidget):
    """The full leads management page."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(0)

        title = QLabel("Lead Table")
        title.setObjectName("PageTitle")
        subtitle = QLabel(
            "All qualifying leads are shown here.  "
            "Right-click a row for options.  "
            "Double-click the Notes column to open the editor."
        )
        subtitle.setObjectName("PageSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(12)

        # ---- Filter bar ----------------------------------------------
        filter_row = QHBoxLayout()
        filter_row.setSpacing(10)

        def _field(placeholder: str, width: int) -> QLineEdit:
            w = QLineEdit()
            w.setPlaceholderText(placeholder)
            w.setFixedWidth(width)
            w.textChanged.connect(self._apply_filters)
            return w

        self._f_name      = _field("Name …",      160)
        self._f_phone     = _field("Phone …",      120)
        self._f_instagram = _field("Instagram …",  130)
        self._f_facebook  = _field("Facebook …",   130)
        self._f_city      = _field("City …",       110)

        self._f_status = QComboBox()
        self._f_status.addItems(ALL_STATUS)
        self._f_status.setFixedWidth(130)
        self._f_status.currentTextChanged.connect(self._apply_filters)

        refresh_btn = QPushButton("⟳  Refresh")
        refresh_btn.setObjectName("SecondaryButton")
        refresh_btn.setFixedWidth(100)
        refresh_btn.clicked.connect(self.refresh)

        clear_btn = QPushButton("✕  Clear")
        clear_btn.setObjectName("SecondaryButton")
        clear_btn.setFixedWidth(80)
        clear_btn.clicked.connect(self._clear_filters)

        for w in [
            self._f_name, self._f_phone, self._f_instagram,
            self._f_facebook, self._f_city, self._f_status,
            refresh_btn, clear_btn,
        ]:
            filter_row.addWidget(w)
        filter_row.addStretch()

        layout.addLayout(filter_row)
        layout.addSpacing(8)

        self._count_lbl = QLabel("0 leads")
        self._count_lbl.setStyleSheet("color: #6c7086; font-size: 12px;")
        layout.addWidget(self._count_lbl)
        layout.addSpacing(4)

        # ---- Table ---------------------------------------------------
        self._table = QTableWidget()
        self._table.setColumnCount(len(COLUMNS))
        self._table.setHorizontalHeaderLabels([c[0] for c in COLUMNS])
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self._table.customContextMenuRequested.connect(self._show_context_menu)
        self._table.doubleClicked.connect(self._handle_double_click)
        self._table.verticalHeader().setDefaultSectionSize(30)
        self._table.verticalHeader().hide()

        hdr = self._table.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hdr.setStretchLastSection(True)
        for col_idx, (_, _, width) in enumerate(COLUMNS):
            self._table.setColumnWidth(col_idx, width)

        layout.addWidget(self._table, stretch=1)

    # ------------------------------------------------------------------
    # Data loading / filtering
    # ------------------------------------------------------------------

    def refresh(self) -> None:
        """Re-apply current filters (re-queries the DB)."""
        self._apply_filters()

    def _apply_filters(self) -> None:
        leads = db.get_leads(
            name_filter=self._f_name.text(),
            phone_filter=self._f_phone.text(),
            instagram_filter=self._f_instagram.text(),
            facebook_filter=self._f_facebook.text(),
            city_filter=self._f_city.text(),
            status_filter=self._f_status.currentText(),
        )
        self._populate_table(leads)

    def _clear_filters(self) -> None:
        for w in [self._f_name, self._f_phone, self._f_instagram,
                  self._f_facebook, self._f_city]:
            w.blockSignals(True)
            w.clear()
            w.blockSignals(False)
        self._f_status.blockSignals(True)
        self._f_status.setCurrentIndex(0)
        self._f_status.blockSignals(False)
        self._apply_filters()

    def _populate_table(self, leads: list[dict]) -> None:
        self._table.setUpdatesEnabled(False)
        self._table.setRowCount(0)
        self._count_lbl.setText(f"{len(leads):,} leads")

        for row_idx, lead in enumerate(leads):
            self._table.insertRow(row_idx)
            lead_id = lead.get("id")

            for col_idx, (_, key, _) in enumerate(COLUMNS):
                value = str(lead.get(key, "") or "")
                item  = QTableWidgetItem(value)
                # Store the DB id on every cell of this row
                item.setData(Qt.ItemDataRole.UserRole, lead_id)

                if key == "status":
                    item.setForeground(QBrush(QColor(
                        STATUS_COLOURS.get(value, "#cdd6f4")
                    )))
                elif key == "lead_type":
                    item.setForeground(QBrush(QColor(
                        LEAD_TYPE_COLOURS.get(value, "#cdd6f4")
                    )))

                self._table.setItem(row_idx, col_idx, item)

        self._table.setUpdatesEnabled(True)

    # ------------------------------------------------------------------
    # Interactions
    # ------------------------------------------------------------------

    def _handle_double_click(self, index) -> None:
        col_key = COLUMNS[index.column()][1]
        if col_key == "notes":
            self._open_notes_editor(index.row())

    def _open_notes_editor(self, row: int) -> None:
        item = self._table.item(row, 0)
        if not item:
            return
        lead_id = item.data(Qt.ItemDataRole.UserRole)
        name    = item.text()

        notes_col  = next(i for i, (_, k, _) in enumerate(COLUMNS) if k == "notes")
        notes_item = self._table.item(row, notes_col)
        notes      = notes_item.text() if notes_item else ""

        dlg = NotesDialog(lead_id, name, notes, parent=self)
        if dlg.exec():
            self.refresh()

    def _show_context_menu(self, pos) -> None:
        row = self._table.rowAt(pos.y())
        if row < 0:
            return
        item = self._table.item(row, 0)
        if not item:
            return
        lead_id = item.data(Qt.ItemDataRole.UserRole)

        menu = QMenu(self)

        status_menu = menu.addMenu("Set Status")
        for s in STATUS_OPTIONS:
            act = QAction(s, self)
            act.triggered.connect(
                lambda checked, _s=s, _id=lead_id: self._set_status(_id, _s)
            )
            status_menu.addAction(act)

        menu.addSeparator()

        notes_act = QAction("✏  Edit Notes", self)
        notes_act.triggered.connect(lambda: self._open_notes_editor(row))
        menu.addAction(notes_act)

        menu.addSeparator()

        del_act = QAction("🗑  Delete Lead", self)
        del_act.triggered.connect(lambda: self._delete_lead(lead_id))
        menu.addAction(del_act)

        menu.exec(self._table.viewport().mapToGlobal(pos))

    def _set_status(self, lead_id: int, status: str) -> None:
        db.update_lead_status(lead_id, status)
        self.refresh()

    def _delete_lead(self, lead_id: int) -> None:
        reply = QMessageBox.question(
            self,
            "Delete Lead",
            "Permanently delete this lead?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            db.delete_lead(lead_id)
            self.refresh()
