"""
About widget — professional branding & application information.
"""

from __future__ import annotations

import os
import sys
from datetime import date

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QScrollArea,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap

# ---------------------------------------------------------------------------
# Asset resolution
# ---------------------------------------------------------------------------
if getattr(sys, "frozen", False):
    _BASE = sys._MEIPASS
else:
    _BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_LOGO_PATH = os.path.join(_BASE, "assets", "logo.png")

APP_VERSION = "1.0"
BUILD_DATE  = date.today().strftime("%B %d, %Y")


# ---------------------------------------------------------------------------
# Widget
# ---------------------------------------------------------------------------

class AboutWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(0)

        page_title = QLabel("About")
        page_title.setObjectName("PageTitle")
        outer.addWidget(page_title)
        outer.addSpacing(16)

        # Scrollable content so it looks clean on small screens
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; }")

        container = QWidget()
        container.setStyleSheet("background: transparent;")
        vbox = QVBoxLayout(container)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(16)

        vbox.addWidget(self._brand_card())
        vbox.addWidget(self._info_card())
        vbox.addWidget(self._stack_card())
        vbox.addWidget(self._legal_card())
        vbox.addStretch()

        scroll.setWidget(container)
        outer.addWidget(scroll, 1)

    # ------------------------------------------------------------------
    # Cards
    # ------------------------------------------------------------------

    def _brand_card(self) -> QFrame:
        """Hero card: logo + studio name + tagline."""
        card = _card()
        cl = card.layout()

        # Logo
        if os.path.exists(_LOGO_PATH):
            logo_pix = QPixmap(_LOGO_PATH)
            if not logo_pix.isNull():
                logo_pix = logo_pix.scaledToWidth(
                    110, Qt.TransformationMode.SmoothTransformation
                )
                logo_lbl = QLabel()
                logo_lbl.setPixmap(logo_pix)
                logo_lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
                cl.addWidget(logo_lbl)
                cl.addSpacing(12)

        # Studio name
        name = QLabel("DARKLIGHTZ STUDIO")
        name.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        name.setStyleSheet(
            "color: #cdd6f4; font-size: 22px; font-weight: bold; letter-spacing: 4px;"
        )
        cl.addWidget(name)

        # Product name
        prod = QLabel("Professional Lead Generation Suite")
        prod.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        prod.setStyleSheet("color: #a6adc8; font-size: 13px; font-weight: 300;")
        cl.addWidget(prod)

        cl.addSpacing(8)

        # Divider
        div = QFrame()
        div.setFrameShape(QFrame.Shape.HLine)
        div.setStyleSheet("color: #313244;")
        cl.addWidget(div)

        cl.addSpacing(8)

        # Tagline
        tag = QLabel("Crafting Inevitable Futures.")
        tag.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        tag.setStyleSheet("color: #6c7086; font-size: 10px; letter-spacing: 3px;")
        cl.addWidget(tag)

        return card

    def _info_card(self) -> QFrame:
        """Version, build date, developer credit."""
        card = _card()
        cl = card.layout()

        _row(cl, "Version",            APP_VERSION)
        _row(cl, "Build Date",         BUILD_DATE)
        _row(cl, "Developed by",       "Darklightz Studio")
        _row(cl, "Professional Focus", "Web Design & Digital Solutions")

        return card

    def _stack_card(self) -> QFrame:
        """Open-source technology stack."""
        card = _card()
        cl = card.layout()

        header = QLabel("Technology Stack")
        header.setStyleSheet("color: #6c7086; font-size: 11px; font-weight: bold;")
        cl.addWidget(header)
        cl.addSpacing(8)

        stack = [
            ("Python 3",            "Core runtime",                                 "PSF"),
            ("PyQt6",               "Desktop UI framework",                         "GPL v3"),
            ("Playwright",          "Browser automation (Google Maps scraping)",     "Apache 2"),
            ("SQLite",              "Local embedded database",                       "Public domain"),
            ("openpyxl",            "Excel .xlsx export",                           "MIT"),
            ("reportlab",           "PDF generation",                               "BSD"),
        ]

        for lib, role, lic in stack:
            row_widget = QWidget()
            row_layout = QHBoxLayout(row_widget)
            row_layout.setContentsMargins(0, 2, 0, 2)

            name_lbl = QLabel(lib)
            name_lbl.setStyleSheet("color: #cba6f7; font-size: 12px; font-weight: bold;")
            name_lbl.setFixedWidth(120)

            role_lbl = QLabel(role)
            role_lbl.setStyleSheet("color: #a6adc8; font-size: 12px;")

            lic_lbl = QLabel(lic)
            lic_lbl.setStyleSheet("color: #45475a; font-size: 10px;")
            lic_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

            row_layout.addWidget(name_lbl)
            row_layout.addWidget(role_lbl, 1)
            row_layout.addWidget(lic_lbl)

            cl.addWidget(row_widget)

        cl.addSpacing(10)
        note = QLabel("100% free & open-source. No paid APIs. No subscriptions. Everything runs locally.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #6c7086; font-size: 10px;")
        cl.addWidget(note)

        return card

    def _legal_card(self) -> QFrame:
        """Legal notice + copyright."""
        card = _card()
        cl = card.layout()

        warning = QLabel(
            "⚠  This application scrapes publicly visible Google Maps data.\n"
            "Use responsibly and in accordance with applicable local laws.\n"
            "Google's Terms of Service prohibit automated scraping — use at your own risk."
        )
        warning.setWordWrap(True)
        warning.setStyleSheet(
            "color: #f9e2af; font-size: 11px; "
            "background: #2a2516; padding: 10px; border-radius: 6px;"
        )
        cl.addWidget(warning)
        cl.addSpacing(12)

        copyright_lbl = QLabel(f"© {date.today().year} Darklightz Studio. All rights reserved.")
        copyright_lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        copyright_lbl.setStyleSheet("color: #45475a; font-size: 10px;")
        cl.addWidget(copyright_lbl)

        return card


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _card() -> QFrame:
    """Return a styled card QFrame with a pre-attached QVBoxLayout."""
    card = QFrame()
    card.setObjectName("StatCard")
    card.setMaximumWidth(680)
    layout = QVBoxLayout(card)
    layout.setContentsMargins(24, 20, 24, 20)
    layout.setSpacing(6)
    return card


def _row(layout, label: str, value: str) -> None:
    """Add a label-value row to *layout*."""
    row = QWidget()
    rl = QHBoxLayout(row)
    rl.setContentsMargins(0, 2, 0, 2)

    lbl = QLabel(label)
    lbl.setStyleSheet("color: #6c7086; font-size: 11px;")
    lbl.setFixedWidth(130)

    val = QLabel(value)
    val.setStyleSheet("color: #cdd6f4; font-size: 12px; font-weight: bold;")

    rl.addWidget(lbl)
    rl.addWidget(val, 1)
    layout.addWidget(row)
