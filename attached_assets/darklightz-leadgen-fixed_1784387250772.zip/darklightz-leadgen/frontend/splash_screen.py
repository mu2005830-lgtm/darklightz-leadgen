"""
Splash screen — shown for 2–3 seconds on startup.

Displays the Darklightz Studio logo, application title, tagline, and version
before the main window appears.
"""

from __future__ import annotations

import os
import sys

from PyQt6.QtWidgets import QSplashScreen, QApplication
from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont, QLinearGradient, QPen
from PyQt6.QtCore import Qt, QRect, QTimer

# ---------------------------------------------------------------------------
# Build-time / run-time asset resolution
# ---------------------------------------------------------------------------

if getattr(sys, "frozen", False):
    _BASE = sys._MEIPASS
else:
    _BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_LOGO_PATH = os.path.join(_BASE, "assets", "logo.png")

APP_VERSION = "1.0"
BUILD_DATE  = "2025"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_logo(target_width: int = 180) -> QPixmap | None:
    """Return a scaled logo pixmap, or None if the file is missing."""
    if not os.path.exists(_LOGO_PATH):
        return None
    pix = QPixmap(_LOGO_PATH)
    if pix.isNull():
        return None
    return pix.scaledToWidth(target_width, Qt.TransformationMode.SmoothTransformation)


def _render_splash(width: int = 560, height: int = 340) -> QPixmap:
    """
    Draw the splash screen onto a QPixmap and return it.

    Layout
    ------
    ┌─────────────────────────────────────┐
    │  [logo]                             │
    │  DARKLIGHTZ STUDIO                  │
    │  Professional Lead Generation Suite │
    │  ───────────────────────────────    │
    │  Developed by Darklightz Studio     │
    │  Version 1.0                        │
    └─────────────────────────────────────┘
    """
    canvas = QPixmap(width, height)
    canvas.fill(Qt.GlobalColor.transparent)

    p = QPainter(canvas)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

    # ── Background gradient ────────────────────────────────────────────
    grad = QLinearGradient(0, 0, 0, height)
    grad.setColorAt(0.0, QColor("#1e1e2e"))   # Catppuccin Mocha base
    grad.setColorAt(1.0, QColor("#11111b"))   # Catppuccin Mocha crust
    p.fillRect(0, 0, width, height, grad)

    # ── Border ─────────────────────────────────────────────────────────
    pen = QPen(QColor("#313244"), 1)           # surface0
    p.setPen(pen)
    p.drawRect(0, 0, width - 1, height - 1)

    # ── Accent line across top ─────────────────────────────────────────
    accent = QLinearGradient(0, 0, width, 0)
    accent.setColorAt(0.0, QColor("#1e1e2e"))
    accent.setColorAt(0.4, QColor("#cba6f7"))   # mauve
    accent.setColorAt(0.6, QColor("#89b4fa"))   # blue
    accent.setColorAt(1.0, QColor("#1e1e2e"))
    p.fillRect(0, 0, width, 3, accent)

    cy = 36   # current vertical cursor

    # ── Logo ───────────────────────────────────────────────────────────
    logo = _load_logo(target_width=130)
    if logo:
        lx = (width - logo.width()) // 2
        p.drawPixmap(lx, cy, logo)
        cy += logo.height() + 20
    else:
        # Fallback monogram when logo file is absent
        p.setPen(QColor("#cba6f7"))
        f = QFont("Arial", 52, QFont.Weight.Bold)
        p.setFont(f)
        p.drawText(QRect(0, cy, width, 70), Qt.AlignmentFlag.AlignHCenter, "DL")
        cy += 80

    # ── Studio name ────────────────────────────────────────────────────
    p.setPen(QColor("#cdd6f4"))
    f = QFont("Segoe UI", 20, QFont.Weight.Bold)
    f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 3)
    p.setFont(f)
    p.drawText(QRect(0, cy, width, 32), Qt.AlignmentFlag.AlignHCenter, "DARKLIGHTZ STUDIO")
    cy += 34

    # ── Tagline ────────────────────────────────────────────────────────
    p.setPen(QColor("#a6adc8"))
    f2 = QFont("Segoe UI", 11)
    f2.setWeight(QFont.Weight.Light)
    p.setFont(f2)
    p.drawText(QRect(0, cy, width, 22), Qt.AlignmentFlag.AlignHCenter,
               "Professional Lead Generation Suite")
    cy += 36

    # ── Divider ────────────────────────────────────────────────────────
    div_x = width // 2 - 80
    p.setPen(QPen(QColor("#45475a"), 1))
    p.drawLine(div_x, cy, div_x + 160, cy)
    cy += 18

    # ── Credit ─────────────────────────────────────────────────────────
    p.setPen(QColor("#6c7086"))
    f3 = QFont("Segoe UI", 9)
    p.setFont(f3)
    p.drawText(QRect(0, cy, width, 18), Qt.AlignmentFlag.AlignHCenter,
               "Developed by Darklightz Studio")
    cy += 20

    # ── Version ────────────────────────────────────────────────────────
    p.setPen(QColor("#45475a"))
    p.drawText(QRect(0, cy, width, 16), Qt.AlignmentFlag.AlignHCenter,
               f"Version {APP_VERSION}")

    p.end()
    return canvas


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class DarklightzSplash(QSplashScreen):
    """
    A self-closing splash screen.

    Usage::

        splash = DarklightzSplash()
        splash.show()
        QApplication.processEvents()
        # … initialise DB, load config …
        splash.finish(main_window)
    """

    def __init__(self):
        pixmap = _render_splash()
        super().__init__(pixmap, Qt.WindowType.WindowStaysOnTopHint)
        self.setWindowFlags(
            Qt.WindowType.SplashScreen
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
        )

    def show_for(self, ms: int = 2500) -> None:
        """Show the splash for *ms* milliseconds, then hide it automatically."""
        self.show()
        QApplication.processEvents()
        QTimer.singleShot(ms, self.close)
