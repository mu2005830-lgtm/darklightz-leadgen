"""
CRUD operations for the Darklightz Lead Generator database.
All functions take/return plain dicts for easy serialisation.
"""

from __future__ import annotations
import sqlite3
from typing import Any
from database.models import get_connection


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _row_to_dict(row: sqlite3.Row) -> dict:
    return dict(row) if row else {}


# ===========================================================================
# SEARCHES
# ===========================================================================

def create_search(keyword: str, city: str, max_leads: int) -> int:
    """Insert a new search session and return its id."""
    conn = get_connection()
    with conn:
        cur = conn.execute(
            "INSERT INTO searches (keyword, city, max_leads) VALUES (?, ?, ?)",
            (keyword.strip(), city.strip(), max_leads),
        )
    conn.close()
    return cur.lastrowid


def complete_search(search_id: int, status: str = "complete") -> None:
    conn = get_connection()
    with conn:
        conn.execute(
            "UPDATE searches SET status=? WHERE id=?",
            (status, search_id),
        )
    conn.close()


def get_all_searches() -> list[dict]:
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM searches ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return [_row_to_dict(r) for r in rows]


def delete_search(search_id: int) -> None:
    """Delete a search session and all its leads (CASCADE)."""
    conn = get_connection()
    with conn:
        conn.execute("DELETE FROM searches WHERE id=?", (search_id,))
    conn.close()


# ===========================================================================
# LEADS
# ===========================================================================

def insert_lead(data: dict) -> int | None:
    """
    Insert a lead.  Returns the new row id, or None if the lead is a duplicate.
    """
    conn = get_connection()
    try:
        with conn:
            cur = conn.execute(
                """
                INSERT OR IGNORE INTO leads
                    (search_id, name, phone, whatsapp, instagram, facebook,
                     address, rating, reviews, website, lead_type,
                     status, notes, city, keyword)
                VALUES
                    (:search_id, :name, :phone, :whatsapp, :instagram, :facebook,
                     :address, :rating, :reviews, :website, :lead_type,
                     :status, :notes, :city, :keyword)
                """,
                data,
            )
        return cur.lastrowid if cur.rowcount else None
    except Exception:
        return None
    finally:
        conn.close()


def get_leads(
    search_id: int | None = None,
    *,
    name_filter: str = "",
    phone_filter: str = "",
    instagram_filter: str = "",
    facebook_filter: str = "",
    city_filter: str = "",
    status_filter: str = "",
) -> list[dict]:
    """Fetch leads with optional filters."""
    params: list[Any] = []
    clauses: list[str] = []

    if search_id is not None:
        clauses.append("search_id = ?")
        params.append(search_id)
    if name_filter:
        clauses.append("LOWER(name) LIKE ?")
        params.append(f"%{name_filter.lower()}%")
    if phone_filter:
        clauses.append("phone LIKE ?")
        params.append(f"%{phone_filter}%")
    if instagram_filter:
        clauses.append("LOWER(instagram) LIKE ?")
        params.append(f"%{instagram_filter.lower()}%")
    if facebook_filter:
        clauses.append("LOWER(facebook) LIKE ?")
        params.append(f"%{facebook_filter.lower()}%")
    if city_filter:
        clauses.append("LOWER(city) LIKE ?")
        params.append(f"%{city_filter.lower()}%")
    if status_filter and status_filter != "All":
        clauses.append("status = ?")
        params.append(status_filter)

    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    sql = f"SELECT * FROM leads {where} ORDER BY created_at DESC"

    conn = get_connection()
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [_row_to_dict(r) for r in rows]


def get_all_leads() -> list[dict]:
    return get_leads()


def update_lead_status(lead_id: int, status: str) -> None:
    conn = get_connection()
    with conn:
        conn.execute(
            "UPDATE leads SET status=?, updated_at=datetime('now') WHERE id=?",
            (status, lead_id),
        )
    conn.close()


def update_lead_notes(lead_id: int, notes: str) -> None:
    conn = get_connection()
    with conn:
        conn.execute(
            "UPDATE leads SET notes=?, updated_at=datetime('now') WHERE id=?",
            (notes, lead_id),
        )
    conn.close()


def update_lead_field(lead_id: int, field: str, value: str) -> None:
    """Update a single safe field on a lead."""
    SAFE_FIELDS = {
        "name", "phone", "whatsapp", "instagram", "facebook",
        "address", "rating", "reviews", "website", "status", "notes",
    }
    if field not in SAFE_FIELDS:
        raise ValueError(f"Field '{field}' is not editable.")
    conn = get_connection()
    with conn:
        conn.execute(
            f"UPDATE leads SET {field}=?, updated_at=datetime('now') WHERE id=?",
            (value, lead_id),
        )
    conn.close()


def delete_lead(lead_id: int) -> None:
    conn = get_connection()
    with conn:
        conn.execute("DELETE FROM leads WHERE id=?", (lead_id,))
    conn.close()


def get_dashboard_stats() -> dict:
    conn = get_connection()
    stats: dict[str, Any] = {}

    stats["total_leads"] = conn.execute("SELECT COUNT(*) FROM leads").fetchone()[0]
    stats["total_searches"] = conn.execute("SELECT COUNT(*) FROM searches").fetchone()[0]
    stats["no_website"] = conn.execute(
        "SELECT COUNT(*) FROM leads WHERE lead_type='No Website'"
    ).fetchone()[0]
    stats["social_only"] = conn.execute(
        "SELECT COUNT(*) FROM leads WHERE lead_type='Social Only'"
    ).fetchone()[0]
    stats["new_leads"] = conn.execute(
        "SELECT COUNT(*) FROM leads WHERE status='New'"
    ).fetchone()[0]
    stats["contacted"] = conn.execute(
        "SELECT COUNT(*) FROM leads WHERE status='Contacted'"
    ).fetchone()[0]
    stats["interested"] = conn.execute(
        "SELECT COUNT(*) FROM leads WHERE status='Interested'"
    ).fetchone()[0]
    stats["closed"] = conn.execute(
        "SELECT COUNT(*) FROM leads WHERE status='Closed'"
    ).fetchone()[0]

    # Recent searches
    rows = conn.execute(
        "SELECT keyword, city, created_at FROM searches ORDER BY created_at DESC LIMIT 5"
    ).fetchall()
    stats["recent_searches"] = [_row_to_dict(r) for r in rows]

    conn.close()
    return stats


# ===========================================================================
# SETTINGS
# ===========================================================================

def get_setting(key: str, default: str = "") -> str:
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    conn = get_connection()
    with conn:
        conn.execute(
            "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
            (key, value),
        )
    conn.close()


def get_all_settings() -> dict:
    conn = get_connection()
    rows = conn.execute("SELECT key, value FROM settings").fetchall()
    conn.close()
    return {r["key"]: r["value"] for r in rows}
