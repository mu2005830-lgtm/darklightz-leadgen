"""
Database models and schema for Darklightz Lead Generator.
Uses SQLite via the built-in sqlite3 module — no external DB required.
"""

import sqlite3
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Database path — stored in user's home dir so it survives reinstalls
# ---------------------------------------------------------------------------
DB_DIR = Path.home() / ".darklightz"
DB_PATH = DB_DIR / "leads.db"


def get_connection() -> sqlite3.Connection:
    """Return a database connection with row_factory set for dict-like access."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")   # faster concurrent reads
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    """Create all tables if they don't exist yet."""
    conn = get_connection()
    with conn:
        conn.executescript("""
            -- ----------------------------------------------------------------
            -- Search sessions — one row per "Start Search" click
            -- ----------------------------------------------------------------
            CREATE TABLE IF NOT EXISTS searches (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                keyword     TEXT    NOT NULL,
                city        TEXT    NOT NULL,
                max_leads   INTEGER NOT NULL DEFAULT 100,
                created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
                status      TEXT    NOT NULL DEFAULT 'running'
                            CHECK(status IN ('running','complete','stopped'))
            );

            -- ----------------------------------------------------------------
            -- Leads — one row per business
            -- ----------------------------------------------------------------
            CREATE TABLE IF NOT EXISTS leads (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                search_id     INTEGER REFERENCES searches(id) ON DELETE CASCADE,
                name          TEXT    NOT NULL DEFAULT '',
                phone         TEXT             DEFAULT '',
                whatsapp      TEXT             DEFAULT '',
                instagram     TEXT             DEFAULT '',
                facebook      TEXT             DEFAULT '',
                address       TEXT             DEFAULT '',
                rating        TEXT             DEFAULT '',
                reviews       TEXT             DEFAULT '',
                website       TEXT             DEFAULT '',
                lead_type     TEXT    NOT NULL DEFAULT 'No Website'
                              CHECK(lead_type IN (
                                  'No Website','Social Only','No Online Presence',
                                  'Facebook Only','Instagram Only','WhatsApp Only'
                              )),
                status        TEXT    NOT NULL DEFAULT 'New'
                              CHECK(status IN (
                                  'New','Contacted','Follow-up',
                                  'Interested','Closed','Not Interested'
                              )),
                notes         TEXT             DEFAULT '',
                city          TEXT             DEFAULT '',
                keyword       TEXT             DEFAULT '',
                created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
                updated_at    TEXT    NOT NULL DEFAULT (datetime('now')),
                UNIQUE(name, phone, city)     -- prevent duplicates
            );

            -- ----------------------------------------------------------------
            -- App settings — key/value store
            -- ----------------------------------------------------------------
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL DEFAULT ''
            );

            -- Sensible defaults for settings
            INSERT OR IGNORE INTO settings VALUES ('export_dir', '');
            INSERT OR IGNORE INTO settings VALUES ('headless',   '1');
            INSERT OR IGNORE INTO settings VALUES ('scroll_delay','1500');
            INSERT OR IGNORE INTO settings VALUES ('page_timeout','30000');
        """)
    conn.close()
