"""
Google Maps scraper for Darklightz Lead Generator.

Runs inside a QThread so the UI stays responsive.
Uses Playwright (Chromium) in sync mode — safe inside a QThread.

Playwright + PyInstaller fix
-----------------------------
When the application is packaged with PyInstaller the Chromium browser
binaries are NOT inside the Python package directory; they live in a
separate folder that is copied next to the .exe during build.

This module detects the frozen state on startup and sets the
PLAYWRIGHT_BROWSERS_PATH environment variable so that Playwright can
locate Chromium without relying on the developer's local installation.

Bugs fixed vs original version
-------------------------------
* Missing `import sys` and `import os` — added.
* No PLAYWRIGHT_BROWSERS_PATH logic for frozen executables — fixed.
* Dedup was broken: tuple checked against a set of strings (never matched).
  Fixed by using two separate sets: seen_labels (feed links) and seen_keys
  (name|phone pairs) for true duplicate prevention.
* urllib.parse imported inside a function — moved to top-level.
* from typing import Callable unused — removed.
* Cookie banner selectors broadened to cover more Google regions.
* Better Google Maps feed selectors with multiple fallbacks.
* Back-button navigation between listings is now handled correctly.
* All errors are written to the rotating log file.
"""

from __future__ import annotations

import os
import re
import sys
import time
import urllib.parse

from PyQt6.QtCore import QThread, pyqtSignal

from utilities.helpers import classify_lead, clean_phone, should_include_lead
from utilities.logger import logger


def _configure_playwright_path() -> None:
    """
    When running as a PyInstaller bundle, tell Playwright where to find
    the bundled Chromium browser.

    During build, `build.bat` copies the `ms-playwright` folder (which
    contains Chromium) next to the `.exe` in the `dist` output directory.
    Setting PLAYWRIGHT_BROWSERS_PATH before `sync_playwright()` is called
    makes Playwright look there instead of the developer's local cache.
    """
    if not getattr(sys, "frozen", False):
        return  # running from source — Playwright uses its default path

    # Directory that contains the .exe
    exe_dir = os.path.dirname(sys.executable)

    # Primary: browsers bundled alongside the exe by build.bat
    bundled = os.path.join(exe_dir, "ms-playwright")
    if os.path.isdir(bundled):
        os.environ["PLAYWRIGHT_BROWSERS_PATH"] = bundled
        logger.info("Playwright browsers path set to bundled: %s", bundled)
        return

    # Fallback: walk up one level (in case of unusual dist layout)
    parent = os.path.join(os.path.dirname(exe_dir), "ms-playwright")
    if os.path.isdir(parent):
        os.environ["PLAYWRIGHT_BROWSERS_PATH"] = parent
        logger.info("Playwright browsers path set to parent: %s", parent)
        return

    logger.warning(
        "Could not find bundled ms-playwright directory next to %s. "
        "Playwright will use the system path — the browser may be missing.",
        exe_dir,
    )


class ScraperWorker(QThread):
    """
    Background thread that drives a Playwright browser, scrapes Google Maps,
    and emits signals for every qualifying lead found.

    Signals
    -------
    progress(int, str)      current found count + status message
    lead_found(dict)        qualifying lead ready to be inserted into DB
    finished(int, bool)     (total_found, stopped_early)
    error(str)              unrecoverable error message
    """

    progress   = pyqtSignal(int, str)
    lead_found = pyqtSignal(dict)
    finished   = pyqtSignal(int, bool)
    error      = pyqtSignal(str)

    def __init__(
        self,
        keyword: str,
        city: str,
        max_leads: int,
        search_id: int,
        headless: bool = True,
        scroll_delay: int = 1500,
        page_timeout: int = 30_000,
        parent=None,
    ):
        super().__init__(parent)
        self.keyword      = keyword.strip()
        self.city         = city.strip()
        self.max_leads    = max_leads
        self.search_id    = search_id
        self.headless     = headless
        self.scroll_delay = scroll_delay   # ms between scroll steps
        self.page_timeout = page_timeout   # ms for network waits
        self._stop_requested = False
        self._found = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def stop(self) -> None:
        """Ask the scrape to stop cleanly after the current listing."""
        self._stop_requested = True

    # ------------------------------------------------------------------
    # QThread entry point
    # ------------------------------------------------------------------

    def run(self) -> None:
        # Configure browser path FIRST, before importing playwright
        _configure_playwright_path()

        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            msg = (
                "Playwright is not installed.\n"
                "Run:  pip install playwright && playwright install chromium"
            )
            logger.error(msg)
            self.error.emit(msg)
            return

        query = f"{self.keyword} {self.city}"
        url   = "https://www.google.com/maps/search/" + query.replace(" ", "+")

        logger.info("Starting scrape: query=%r  max=%d", query, self.max_leads)

        try:
            with sync_playwright() as pw:
                browser = pw.chromium.launch(
                    headless=self.headless,
                    args=[
                        "--no-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-blink-features=AutomationControlled",
                    ],
                )
                context = browser.new_context(
                    user_agent=(
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/124.0.0.0 Safari/537.36"
                    ),
                    viewport={"width": 1280, "height": 900},
                    locale="en-US",
                )
                page = context.new_page()
                page.set_default_timeout(self.page_timeout)

                try:
                    self.progress.emit(0, f"Opening Google Maps for: {query}")
                    page.goto(url, wait_until="domcontentloaded")
                    self._sleep(2.5)
                    self._dismiss_cookie_banner(page)
                    self._scrape_feed(page)

                except Exception as exc:
                    logger.exception("Scraper loop error")
                    self.error.emit(f"Scraper error: {exc}")
                finally:
                    try:
                        browser.close()
                    except Exception:
                        pass

        except Exception as exc:
            logger.exception("Playwright launch error")
            self.error.emit(f"Failed to launch browser: {exc}")

        stopped_early = self._stop_requested
        logger.info("Scrape finished. found=%d  stopped_early=%s", self._found, stopped_early)
        self.finished.emit(self._found, stopped_early)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _sleep(self, seconds: float) -> None:
        """Interruptible sleep — checks stop flag every 0.25 s."""
        slept = 0.0
        while slept < seconds and not self._stop_requested:
            time.sleep(min(0.25, seconds - slept))
            slept += 0.25

    def _dismiss_cookie_banner(self, page) -> None:
        """Accept / dismiss the cookie consent banner that Google shows in some regions."""
        selectors = [
            'button[aria-label*="Accept all"]',
            'button[aria-label*="Accept"]',
            'button[jsname="b3VHJd"]',   # common Google consent button
            'form:nth-child(2) button',
        ]
        for sel in selectors:
            try:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    self._sleep(1)
                    return
            except Exception:
                continue

    # ------------------------------------------------------------------
    # Feed iteration
    # ------------------------------------------------------------------

    def _scrape_feed(self, page) -> None:
        """
        Iterate the Google Maps sidebar results, click each listing,
        extract details, and emit qualifying leads.

        Two separate dedup sets:
        - seen_labels  : href/aria-label of each feed item (prevents re-clicking)
        - seen_keys    : "name|phone" fingerprint (prevents duplicate leads)
        """
        seen_labels: set[str] = set()   # feed item identifiers
        seen_keys:   set[str] = set()   # lead dedup fingerprints
        no_new_count = 0

        while self._found < self.max_leads and not self._stop_requested:

            # ---- Collect all clickable listing links in the feed --------
            link_els = self._get_feed_links(page)

            new_this_pass = 0

            for link_el in link_els:
                if self._stop_requested or self._found >= self.max_leads:
                    break

                try:
                    # Build a stable identifier for this feed item
                    href  = link_el.get_attribute("href")  or ""
                    label = link_el.get_attribute("aria-label") or ""
                    uid   = href or label
                    if not uid or uid in seen_labels:
                        continue

                    seen_labels.add(uid)
                    new_this_pass += 1

                    self.progress.emit(
                        self._found,
                        f"Checking: {label or href[:60]}",
                    )

                    # Click listing and wait for detail panel
                    try:
                        link_el.click()
                        self._sleep(2.2)
                    except Exception:
                        continue

                    # Extract detail panel
                    data = self._extract_detail(page)
                    if not data or not data.get("name"):
                        continue

                    # Dedup by name + phone
                    dedup_key = (
                        data["name"].lower().strip()
                        + "|"
                        + data.get("phone", "").strip()
                    )
                    if dedup_key in seen_keys:
                        continue
                    seen_keys.add(dedup_key)

                    # Filter — skip businesses with real websites
                    if not should_include_lead(data.get("website", "")):
                        self.progress.emit(
                            self._found,
                            f"Skipped (has website): {data['name']}",
                        )
                        continue

                    # Build final lead dict
                    lead_type = classify_lead(data.get("website", ""))
                    data.update(
                        lead_type=lead_type,
                        search_id=self.search_id,
                        status="New",
                        notes="",
                        city=self.city,
                        keyword=self.keyword,
                    )

                    self._found += 1
                    logger.debug("Lead found: %s [%s]", data["name"], lead_type)
                    self.progress.emit(self._found, f"Found: {data['name']}")
                    self.lead_found.emit(data)

                except Exception as exc:
                    logger.debug("Error processing listing: %s", exc)
                    continue

            # ---- Stall detection ----------------------------------------
            if new_this_pass == 0:
                no_new_count += 1
                if no_new_count >= 5:
                    self.progress.emit(self._found, "No more results available.")
                    logger.info("Feed exhausted after %d consecutive empty passes.", no_new_count)
                    break
            else:
                no_new_count = 0

            # ---- Scroll the feed panel ----------------------------------
            try:
                scrolled = page.evaluate(
                    """
                    (() => {
                        const feed = document.querySelector('div[role="feed"]');
                        if (!feed) return false;
                        feed.scrollTop += 2000;
                        return true;
                    })()
                    """
                )
                if not scrolled:
                    logger.warning("Feed panel not found for scrolling.")
                    break
                self._sleep(self.scroll_delay / 1000)
            except Exception as exc:
                logger.debug("Scroll error: %s", exc)
                break

    def _get_feed_links(self, page) -> list:
        """
        Return all clickable listing links from the feed panel.
        Tries multiple selector strategies for resilience against
        Google Maps DOM changes.
        """
        strategies = [
            # Primary: direct anchor tags inside the feed with a place href
            'div[role="feed"] a[href*="/maps/place/"]',
            # Fallback 1: any anchor with jsaction inside feed
            'div[role="feed"] a[jsaction]',
            # Fallback 2: div children of feed that contain links
            'div[role="feed"] > div[jsaction]',
        ]
        for sel in strategies:
            try:
                els = page.query_selector_all(sel)
                if els:
                    return els
            except Exception:
                continue
        return []

    # ------------------------------------------------------------------
    # Detail panel extraction
    # ------------------------------------------------------------------

    def _extract_detail(self, page) -> dict | None:
        """
        Extract structured data from the currently visible detail panel.
        Uses multiple selector strategies per field.
        Returns None if the business name cannot be found.
        """
        data: dict = {
            "name":      "",
            "phone":     "",
            "whatsapp":  "",
            "instagram": "",
            "facebook":  "",
            "address":   "",
            "rating":    "",
            "reviews":   "",
            "website":   "",
        }

        try:
            self._sleep(0.6)

            # ---- Name -----------------------------------------------
            for sel in [
                'h1.DUwDvf',
                'h1[class*="DUwDvf"]',
                'div[role="main"] h1',
                'h1',
            ]:
                el = page.query_selector(sel)
                if el:
                    txt = el.inner_text().strip()
                    if txt:
                        data["name"] = txt
                        break

            # ---- Rating ---------------------------------------------
            for sel in [
                'div.F7nice span[aria-hidden="true"]',
                'span.ceNzKf',
                'div[role="main"] span[aria-label*="stars"]',
            ]:
                el = page.query_selector(sel)
                if el:
                    txt = el.inner_text().strip()
                    if txt:
                        data["rating"] = txt
                        break

            # Also try aria-label approach for rating
            if not data["rating"]:
                for sel in ['span[aria-label*=" stars"]', 'span[aria-label*=" star"]']:
                    el = page.query_selector(sel)
                    if el:
                        lbl = el.get_attribute("aria-label") or ""
                        m = re.search(r"([\d.]+)", lbl)
                        if m:
                            data["rating"] = m.group(1)
                            break

            # ---- Review count ----------------------------------------
            for sel in [
                'span[aria-label*="reviews"]',
                'span[aria-label*="review"]',
                'div.F7nice span:not([aria-hidden])',
            ]:
                el = page.query_selector(sel)
                if el:
                    txt = el.inner_text().strip().replace("(", "").replace(")", "").strip()
                    if txt and txt.isdigit() or re.search(r"\d", txt):
                        data["reviews"] = txt
                        break

            # ---- Address --------------------------------------------
            # Strategy 1: data-item-id button
            for btn in page.query_selector_all('button[data-item-id*="address"]'):
                inner = btn.query_selector("div.rogA2c, div[class*='rogA2c'], div > div")
                if inner:
                    txt = inner.inner_text().strip()
                    if txt:
                        data["address"] = txt
                        break
            # Strategy 2: aria-label
            if not data["address"]:
                for btn in page.query_selector_all('button[aria-label*="Address"]'):
                    lbl = btn.get_attribute("aria-label") or ""
                    addr = re.sub(r"^Address:\s*", "", lbl).strip()
                    if addr:
                        data["address"] = addr
                        break
            # Strategy 3: text containing common address patterns
            if not data["address"]:
                try:
                    els = page.query_selector_all('div[role="main"] button')
                    for el in els:
                        txt = el.inner_text().strip()
                        if re.search(r'\d+.{1,50}(Street|Road|Ave|Blvd|St\b|Rd\b|Ln\b|Dr\b|Sector|Block|Phase|Town|City)', txt, re.I):
                            data["address"] = txt
                            break
                except Exception:
                    pass

            # ---- Phone ----------------------------------------------
            for sel in [
                'button[data-item-id*="phone:tel"]',
                'button[data-tooltip*="Copy phone"]',
                'button[aria-label*="Phone"]',
            ]:
                el = page.query_selector(sel)
                if el:
                    raw = (
                        el.get_attribute("data-item-id")
                        or el.get_attribute("aria-label")
                        or el.inner_text()
                        or ""
                    )
                    phone = re.sub(r"(?i)phone:tel:", "", raw).strip()
                    phone = re.sub(r"(?i)^phone:\s*", "", phone).strip()
                    phone = re.sub(r"(?i)^copy phone number\s*", "", phone).strip()
                    phone = clean_phone(phone)
                    if phone:
                        data["phone"] = phone
                        break

            # ---- Website --------------------------------------------
            for sel in [
                'a[data-item-id="authority"]',
                'a[aria-label*="website" i]',
                'a[data-tooltip*="Open website"]',
                'div[role="main"] a[target="_blank"][href^="http"]:not([href*="google"])',
            ]:
                el = page.query_selector(sel)
                if el:
                    href = el.get_attribute("href") or ""
                    # Strip Google redirect wrapper
                    m = re.search(r"[?&]url=([^&]+)", href)
                    if m:
                        href = urllib.parse.unquote(m.group(1))
                    # Skip internal Google URLs
                    if href and "google.com" not in href and href.startswith("http"):
                        data["website"] = href
                        break

            # ---- Social links from panel HTML -----------------------
            try:
                panel_html = page.inner_html('div[role="main"]')
                self._extract_socials(panel_html, data)
            except Exception:
                pass

            # ---- WhatsApp fallback from phone -----------------------
            if not data["whatsapp"] and data["phone"]:
                digits = re.sub(r"\D", "", data["phone"])
                if len(digits) >= 7:
                    data["whatsapp"] = f"https://wa.me/{digits}"

        except Exception as exc:
            logger.debug("Detail extraction error: %s", exc)

        return data if data.get("name") else None

    # ------------------------------------------------------------------
    # Social link helpers
    # ------------------------------------------------------------------

    def _extract_socials(self, html: str, data: dict) -> None:
        """Scan panel HTML for social media profile links."""
        # Instagram
        if not data.get("instagram"):
            m = re.search(r"instagram\.com/([A-Za-z0-9._]+)(?:[/?]|$)", html, re.I)
            if m and m.group(1) not in {"p", "explore", "accounts", "tv", "reel"}:
                data["instagram"] = f"https://instagram.com/{m.group(1)}"

        # Facebook
        if not data.get("facebook"):
            m = re.search(
                r"facebook\.com/(?:pg/|pages/|profile\.php\?id=)?([A-Za-z0-9_./-]+)",
                html, re.I,
            )
            if m:
                slug = m.group(1).rstrip("/").split("?")[0]
                if slug and slug not in {"sharer", "share", "login", "dialog", "photo"}:
                    data["facebook"] = f"https://facebook.com/{slug}"

        # WhatsApp (explicit wa.me links take priority over phone fallback)
        if not data.get("whatsapp"):
            m = re.search(r"wa\.me/(\d{7,15})", html, re.I)
            if m:
                data["whatsapp"] = f"https://wa.me/{m.group(1)}"
