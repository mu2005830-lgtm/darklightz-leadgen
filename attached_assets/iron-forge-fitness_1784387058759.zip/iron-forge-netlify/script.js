document.addEventListener('DOMContentLoaded', () => {
  
  // 1. Loading Screen
  const loadingScreen = document.getElementById('loading-screen');
  setTimeout(() => {
    loadingScreen.style.opacity = '0';
    setTimeout(() => {
      loadingScreen.style.visibility = 'hidden';
      // Trigger hero animations after loader
      document.querySelectorAll('#hero .fade-up').forEach(el => {
        el.classList.add('visible');
      });
      initCounter();
    }, 500);
  }, 1500);

  // 2. Navigation Scroll & Mobile Menu
  const navbar = document.getElementById('navbar');
  const hamburger = document.querySelector('.nav-hamburger');
  const mobileMenu = document.querySelector('.mobile-menu');
  const mobileLinks = document.querySelectorAll('.mobile-link');
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    mobileMenu.classList.toggle('active');
    document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
  });

  mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('active');
      mobileMenu.classList.remove('active');
      document.body.style.overflow = '';
    });
  });

  // 3. Intersection Observer for Fade-Up Animations
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
  };

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        if(entry.target.id === 'hero-stats') {
          initCounter();
        }
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.fade-up').forEach(el => {
    // Don't observe hero elements initially if we handle them after loader
    if (!el.closest('#hero')) {
      observer.observe(el);
    }
  });

  // 4. Counter Animation
  let counterStarted = false;
  function initCounter() {
    if (counterStarted) return;
    counterStarted = true;
    
    const counters = document.querySelectorAll('.stat-number');
    const speed = 200; 

    counters.forEach(counter => {
      const updateCount = () => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText;
        const inc = target / speed;

        if (count < target) {
          counter.innerText = Math.ceil(count + inc);
          setTimeout(updateCount, 10);
        } else {
          // Format with commas if over 1000
          counter.innerText = target >= 1000 ? target.toLocaleString() : target;
        }
      };
      updateCount();
    });
  }

  // 5. Button Ripple Effect
  document.querySelectorAll('.ripple').forEach(button => {
    button.addEventListener('click', function(e) {
      // Create ripple element
      const ripple = document.createElement('span');
      ripple.classList.add('ripple-effect');
      
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      
      ripple.style.width = ripple.style.height = `${size}px`;
      
      // Calculate click position relative to button
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;
      
      ripple.style.left = `${x}px`;
      ripple.style.top = `${y}px`;
      
      this.appendChild(ripple);
      
      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });

  // 6. Membership Billing Toggle
  const billingSwitch = document.getElementById('billing-switch');
  const amounts = document.querySelectorAll('.plan-price .amount');
  
  if (billingSwitch) {
    billingSwitch.addEventListener('change', function() {
      const isAnnual = this.checked;
      
      amounts.forEach(amount => {
        const monthly = amount.getAttribute('data-monthly');
        const annual = amount.getAttribute('data-annual');
        
        // Simple fade out/in effect
        amount.style.opacity = '0';
        setTimeout(() => {
          amount.innerText = isAnnual ? annual : monthly;
          amount.style.opacity = '1';
        }, 200);
      });
    });
  }

  // 7. Lightbox Gallery
  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.querySelector('.lightbox-img');
  const lightboxClose = document.querySelector('.lightbox-close');

  if (lightbox) {
    galleryItems.forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const imgSrc = this.querySelector('img').src;
        lightboxImg.src = imgSrc;
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
      });
    });

    lightboxClose.addEventListener('click', () => {
      lightbox.classList.remove('active');
      document.body.style.overflow = '';
    });

    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }

  // 8. BMI Calculator
  const bmiForm = document.getElementById('bmi-form');
  const bmiResult = document.getElementById('bmi-result');
  const bmiValue = document.getElementById('bmi-value');
  const bmiCategory = document.getElementById('bmi-category');

  if (bmiForm) {
    bmiForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const height = parseFloat(document.getElementById('height').value) / 100; // to meters
      const weight = parseFloat(document.getElementById('weight').value);
      
      if (height > 0 && weight > 0) {
        const bmi = (weight / (height * height)).toFixed(1);
        bmiValue.innerText = bmi;
        
        let category = '';
        let className = '';
        
        if (bmi < 18.5) {
          category = 'Underweight';
          className = 'cat-underweight';
        } else if (bmi >= 18.5 && bmi < 24.9) {
          category = 'Normal Weight';
          className = 'cat-normal';
        } else if (bmi >= 25 && bmi < 29.9) {
          category = 'Overweight';
          className = 'cat-overweight';
        } else {
          category = 'Obese';
          className = 'cat-obese';
        }
        
        bmiCategory.innerText = category;
        bmiCategory.className = `result-category ${className}`;
        
        bmiResult.classList.remove('hidden');
      }
    });
  }

  // 9. FAQ Accordion
  const accordionHeaders = document.querySelectorAll('.accordion-header');
  
  accordionHeaders.forEach(header => {
    header.addEventListener('click', function() {
      const item = this.parentElement;
      const content = item.querySelector('.accordion-content');
      
      // Close all others
      document.querySelectorAll('.accordion-item').forEach(otherItem => {
        if (otherItem !== item && otherItem.classList.contains('active')) {
          otherItem.classList.remove('active');
          otherItem.querySelector('.accordion-content').style.maxHeight = null;
        }
      });
      
      // Toggle current
      item.classList.toggle('active');
      
      if (item.classList.contains('active')) {
        content.style.maxHeight = content.scrollHeight + "px";
      } else {
        content.style.maxHeight = null;
      }
    });
  });

  // 10. Contact Form Submission
  const contactForm = document.getElementById('contact-form');
  const formSuccess = document.getElementById('form-success');
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Simulate form submission
      const btn = this.querySelector('button[type="submit"]');
      const originalText = btn.innerText;
      
      btn.innerText = 'SENDING...';
      btn.style.opacity = '0.7';
      btn.disabled = true;
      
      setTimeout(() => {
        contactForm.reset();
        btn.innerText = originalText;
        btn.style.opacity = '1';
        btn.disabled = false;
        
        formSuccess.classList.remove('hidden');
        
        setTimeout(() => {
          formSuccess.classList.add('hidden');
        }, 5000);
      }, 1500);
    });
  }

  // 11. Smooth Scroll for Anchor Links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        e.preventDefault();
        
        // Adjust for fixed navbar
        const navHeight = document.querySelector('.navbar').offsetHeight;
        const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - navHeight;
        
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });
});